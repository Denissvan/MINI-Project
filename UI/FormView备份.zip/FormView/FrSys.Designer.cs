﻿namespace UI
{
    partial class FrSys
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ctb_sys = new CTabControl();
            this.tp_card = new System.Windows.Forms.TabPage();
            this.lb_card_update_ms = new System.Windows.Forms.Label();
            this.CardTable = new MotionCtrl.CardTable();
            this.tp_axis = new System.Windows.Forms.TabPage();
            this.btn_update_card = new System.Windows.Forms.Button();
            this.btn_stop = new System.Windows.Forms.Button();
            this.lb_ax_update_ms = new System.Windows.Forms.Label();
            this.ctb_ax_sel = new CTabControl();
            this.ctp_ax_udl1 = new System.Windows.Forms.TabPage();
            this.ctp_ax_udl2 = new System.Windows.Forms.TabPage();
            this.ctp_ax_lc = new System.Windows.Forms.TabPage();
            this.ctp_ax_box_left = new System.Windows.Forms.TabPage();
            this.ctp_ax_box_right = new System.Windows.Forms.TabPage();
            this.ctp_ax_otp = new System.Windows.Forms.TabPage();
            this.ctp_ax_ws = new System.Windows.Forms.TabPage();
            this.ctp_ax_all = new System.Windows.Forms.TabPage();
            this.label_ax_table = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_load_axis_cfg = new System.Windows.Forms.Button();
            this.btn_save_axis_cfg = new System.Windows.Forms.Button();
            this.axisConfig = new MotionCtrl.AxisConfig();
            this.axisTable = new MotionCtrl.AxisTable();
            this.tp_gpio = new System.Windows.Forms.TabPage();
            this.ctb_io_type = new CTabControl();
            this.tp_out = new System.Windows.Forms.TabPage();
            this.tp_in = new System.Windows.Forms.TabPage();
            this.tp_cy = new System.Windows.Forms.TabPage();
            this.lb_io_update_ms = new System.Windows.Forms.Label();
            this.cylinderTable = new MotionCtrl.CylinderTable();
            this.ioTable = new MotionCtrl.IOTable();
            this.tp_sysparm = new System.Windows.Forms.TabPage();
            this.ctb_SetParm = new CTabControl();
            this.tp_setparm_1 = new System.Windows.Forms.TabPage();
            this.groupBox44 = new System.Windows.Forms.GroupBox();
            this.nud_TestTime = new System.Windows.Forms.NumericUpDown();
            this.groupBox39 = new System.Windows.Forms.GroupBox();
            this.nud_JigSendTime = new System.Windows.Forms.NumericUpDown();
            this.groupBox38 = new System.Windows.Forms.GroupBox();
            this.groupBox45 = new System.Windows.Forms.GroupBox();
            this.rabt_jigscan_ON = new System.Windows.Forms.RadioButton();
            this.rabt_jigscan_OFF = new System.Windows.Forms.RadioButton();
            this.groupBox43 = new System.Windows.Forms.GroupBox();
            this.btnStartJigSan4 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.groupBox42 = new System.Windows.Forms.GroupBox();
            this.btnStartJigSan3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.groupBox41 = new System.Windows.Forms.GroupBox();
            this.btnStartJigSan2 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.groupBox40 = new System.Windows.Forms.GroupBox();
            this.btnStartJigSan1 = new System.Windows.Forms.RadioButton();
            this.btnStopJigSan = new System.Windows.Forms.RadioButton();
            this.groupBox34 = new System.Windows.Forms.GroupBox();
            this.nud_ngscale = new System.Windows.Forms.NumericUpDown();
            this.nud_ngcode = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.rbtn_ngcontroldis = new System.Windows.Forms.RadioButton();
            this.rbtn_ngcontrolen = new System.Windows.Forms.RadioButton();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.rbtn_OkCheckDis = new System.Windows.Forms.RadioButton();
            this.rbtn_OkCheckEn = new System.Windows.Forms.RadioButton();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.chk_UpLoadData = new System.Windows.Forms.CheckBox();
            this.chk_UpdateSoft = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.chk_dwcam2 = new System.Windows.Forms.CheckBox();
            this.chk_upcam2 = new System.Windows.Forms.CheckBox();
            this.chk_dwcam1 = new System.Windows.Forms.CheckBox();
            this.chk_upcam1 = new System.Windows.Forms.CheckBox();
            this.grb_safe = new System.Windows.Forms.GroupBox();
            this.chk_rightlightbox = new System.Windows.Forms.CheckBox();
            this.chk_tray = new System.Windows.Forms.CheckBox();
            this.chk_leftlightbox = new System.Windows.Forms.CheckBox();
            this.chk_updown = new System.Windows.Forms.CheckBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.nud_OpenDly = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.rbtn_next_turnon = new System.Windows.Forms.RadioButton();
            this.rbtn_pre_turnon = new System.Windows.Forms.RadioButton();
            this.groupBoxbarcode = new System.Windows.Forms.GroupBox();
            this.rbtn_CloseBarCamBack = new System.Windows.Forms.RadioButton();
            this.rbtn_OpenBarCamBack = new System.Windows.Forms.RadioButton();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.rbtn_Lag = new System.Windows.Forms.RadioButton();
            this.rbtn_Sml = new System.Windows.Forms.RadioButton();
            this.rbtn_single = new System.Windows.Forms.RadioButton();
            this.rbtn_double = new System.Windows.Forms.RadioButton();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.rbtn_big = new System.Windows.Forms.RadioButton();
            this.rbtn_small = new System.Windows.Forms.RadioButton();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.nud_SameRowNGTipCnt = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.chk_SameRowNGTip = new System.Windows.Forms.CheckBox();
            this.btn_ptset_save = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nud_MovUpDly = new System.Windows.Forms.NumericUpDown();
            this.nud_PlaceDly = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Chk_ModPasteUp = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.nud_vschk_rofs = new System.Windows.Forms.NumericUpDown();
            this.nud_vschk_xyofs = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Chk_OpenVs = new System.Windows.Forms.CheckBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.nud_SameNGTipCnt = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.chk_SameNGTip = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.nud_grrtudlcnt = new System.Windows.Forms.NumericUpDown();
            this.nud_grrtestcnt = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.chk_grr = new System.Windows.Forms.CheckBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.nud_dwCam_xt4_ofs = new System.Windows.Forms.NumericUpDown();
            this.nud_dwCam_xt3_ofs = new System.Windows.Forms.NumericUpDown();
            this.nud_dwCam_xt2_ofs = new System.Windows.Forms.NumericUpDown();
            this.nud_dwCam_xt1_ofs = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.grb_barcode = new System.Windows.Forms.GroupBox();
            this.rbtn_NoCap = new System.Windows.Forms.RadioButton();
            this.rbtn_dwcode = new System.Windows.Forms.RadioButton();
            this.rbtn_upcode = new System.Windows.Forms.RadioButton();
            this.grb_runmode = new System.Windows.Forms.GroupBox();
            this.rbtn_run_updw = new System.Windows.Forms.RadioButton();
            this.rbtn_run_empty = new System.Windows.Forms.RadioButton();
            this.rbtn_run_normal = new System.Windows.Forms.RadioButton();
            this.grb_workmode = new System.Windows.Forms.GroupBox();
            this.rbtn_md2 = new System.Windows.Forms.RadioButton();
            this.rbtn_twomd = new System.Windows.Forms.RadioButton();
            this.rbtn_md1 = new System.Windows.Forms.RadioButton();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.nud_EquipmentMaintain = new System.Windows.Forms.NumericUpDown();
            this.nud_FixtrueMaintain = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.nud_GTMOfs = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.chk_GTMCheck = new System.Windows.Forms.CheckBox();
            this.tp_setparm_2 = new System.Windows.Forms.TabPage();
            this.groupBox48 = new System.Windows.Forms.GroupBox();
            this.cb_ConnectorCheck = new System.Windows.Forms.CheckBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.nud_Areaofset = new System.Windows.Forms.NumericUpDown();
            this.label39 = new System.Windows.Forms.Label();
            this.nud_DownArea = new System.Windows.Forms.NumericUpDown();
            this.nud_UpArea = new System.Windows.Forms.NumericUpDown();
            this.nud_RightArea = new System.Windows.Forms.NumericUpDown();
            this.nud_LeftArea = new System.Windows.Forms.NumericUpDown();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.nud_Areaofset2 = new System.Windows.Forms.NumericUpDown();
            this.label40 = new System.Windows.Forms.Label();
            this.nud_DownArea2 = new System.Windows.Forms.NumericUpDown();
            this.nud_UpArea2 = new System.Windows.Forms.NumericUpDown();
            this.nud_RightArea2 = new System.Windows.Forms.NumericUpDown();
            this.nud_LeftArea2 = new System.Windows.Forms.NumericUpDown();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rad_light_xsj = new System.Windows.Forms.RadioButton();
            this.rad_G4C = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.rbtn_Y1dis = new System.Windows.Forms.RadioButton();
            this.rbtn_Y1en = new System.Windows.Forms.RadioButton();
            this.groupBox47 = new System.Windows.Forms.GroupBox();
            this.rbtn_safeoff = new System.Windows.Forms.RadioButton();
            this.rbtn_safeon = new System.Windows.Forms.RadioButton();
            this.groupBox46 = new System.Windows.Forms.GroupBox();
            this.rbtn_AddCapQrcodeDis = new System.Windows.Forms.RadioButton();
            this.rbtn_AddCapQrcodeEn = new System.Windows.Forms.RadioButton();
            this.groupBox37 = new System.Windows.Forms.GroupBox();
            this.rbtn_MesRemote = new System.Windows.Forms.RadioButton();
            this.rbtn_MesLocal = new System.Windows.Forms.RadioButton();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.nud_okRate = new System.Windows.Forms.NumericUpDown();
            this.rbtn_NgWarningDis = new System.Windows.Forms.RadioButton();
            this.rbtn_NgWarningEn = new System.Windows.Forms.RadioButton();
            this.groupBox35 = new System.Windows.Forms.GroupBox();
            this.rbtn_ContinuousAlarmDis = new System.Windows.Forms.RadioButton();
            this.rbtn_ContinuousAlarmEn = new System.Windows.Forms.RadioButton();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.rbtn_delaytestdis = new System.Windows.Forms.RadioButton();
            this.rbtn_delaytesten = new System.Windows.Forms.RadioButton();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.rbtn_cooldis = new System.Windows.Forms.RadioButton();
            this.rbtn_coolen = new System.Windows.Forms.RadioButton();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.rbtn_CycleDis = new System.Windows.Forms.RadioButton();
            this.rbtn_CycleEn = new System.Windows.Forms.RadioButton();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.nud_jig_exposure2 = new System.Windows.Forms.NumericUpDown();
            this.nud_jig_contrast2 = new System.Windows.Forms.NumericUpDown();
            this.nud_jig_brightness2 = new System.Windows.Forms.NumericUpDown();
            this.label33 = new System.Windows.Forms.Label();
            this.nud_jig_exposure1 = new System.Windows.Forms.NumericUpDown();
            this.nud_jig_contrast1 = new System.Windows.Forms.NumericUpDown();
            this.nud_jig_brightness1 = new System.Windows.Forms.NumericUpDown();
            this.label31 = new System.Windows.Forms.Label();
            this.nud_ws_exposure2 = new System.Windows.Forms.NumericUpDown();
            this.nud_tray_exposure2 = new System.Windows.Forms.NumericUpDown();
            this.nud_ws_contrast2 = new System.Windows.Forms.NumericUpDown();
            this.nud_ws_brightness2 = new System.Windows.Forms.NumericUpDown();
            this.nud_tray_contrast2 = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.nud_tray_brightness2 = new System.Windows.Forms.NumericUpDown();
            this.label27 = new System.Windows.Forms.Label();
            this.nud_ws_exposure1 = new System.Windows.Forms.NumericUpDown();
            this.nud_tray_exposure1 = new System.Windows.Forms.NumericUpDown();
            this.nud_ws_contrast1 = new System.Windows.Forms.NumericUpDown();
            this.nud_ws_brightness1 = new System.Windows.Forms.NumericUpDown();
            this.nud_tray_contrast1 = new System.Windows.Forms.NumericUpDown();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.nud_tray_brightness1 = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.rbtn_camcfgsetdis = new System.Windows.Forms.RadioButton();
            this.rbtn_camcfgseten = new System.Windows.Forms.RadioButton();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.nud_cleaninterval = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.rbtn_cleandis = new System.Windows.Forms.RadioButton();
            this.rbtn_cleanen = new System.Windows.Forms.RadioButton();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.rbtn_nonparalleldis = new System.Windows.Forms.RadioButton();
            this.rbtn_nonparallelen = new System.Windows.Forms.RadioButton();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.rbtn_backerrcontinuedis = new System.Windows.Forms.RadioButton();
            this.rbtn_backerrcontinueen = new System.Windows.Forms.RadioButton();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.rbtn_RY1dis = new System.Windows.Forms.RadioButton();
            this.rbtn_RY1en = new System.Windows.Forms.RadioButton();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.rbtn_xt1firstdis = new System.Windows.Forms.RadioButton();
            this.rbtn_xt1firsten = new System.Windows.Forms.RadioButton();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.rbtn_traybardis = new System.Windows.Forms.RadioButton();
            this.rbtn_traybaren = new System.Windows.Forms.RadioButton();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.rbtn_halldis = new System.Windows.Forms.RadioButton();
            this.rbtn_hallen = new System.Windows.Forms.RadioButton();
            this.btn_saveparm2 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbtn_CloseVsTray = new System.Windows.Forms.RadioButton();
            this.rbtn_OpenVsTray = new System.Windows.Forms.RadioButton();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.rbtn_CloseWsPickAgain = new System.Windows.Forms.RadioButton();
            this.rbtn_OpenWsPickAgain = new System.Windows.Forms.RadioButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.nud_offset_degree = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.rbtn_close_degree = new System.Windows.Forms.RadioButton();
            this.rbtn_open_degree = new System.Windows.Forms.RadioButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.rbtn_CloseWsVsAddCheck = new System.Windows.Forms.RadioButton();
            this.rbtn_OpenWsVsAddCheck = new System.Windows.Forms.RadioButton();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.rbtn_lbdis = new System.Windows.Forms.RadioButton();
            this.rbtn_lben = new System.Windows.Forms.RadioButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox52 = new System.Windows.Forms.GroupBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.tb_eqp_pos = new System.Windows.Forms.TextBox();
            this.tb_eqp_sn = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox49 = new System.Windows.Forms.GroupBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox50 = new System.Windows.Forms.GroupBox();
            this.rbtUpDn1OneXtOff = new System.Windows.Forms.RadioButton();
            this.rbtUpDn1OneXtOn = new System.Windows.Forms.RadioButton();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox51 = new System.Windows.Forms.GroupBox();
            this.rbtUpDn2OneXtOff = new System.Windows.Forms.RadioButton();
            this.rbtUpDn2OneXtOn = new System.Windows.Forms.RadioButton();
            this.tp_calc = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.ctb_cali = new CTabControl();
            this.tb_upcam1_npoint = new System.Windows.Forms.TabPage();
            this.npointCail1 = new UI.Compment.NpointCail();
            this.tb_dwcam1_to_upcam1 = new System.Windows.Forms.TabPage();
            this.affineCail_Dw1ToUp1 = new UI.Compment.AffineCail();
            this.tb_dwcam2_to_upcam2 = new System.Windows.Forms.TabPage();
            this.affineCail_Dw2ToUp2 = new UI.Compment.AffineCail();
            this.Tb_ComputeCenter = new System.Windows.Forms.TabPage();
            this.rotAndFly1 = new UI.Compment.RotAndFly();
            this.button32 = new System.Windows.Forms.Button();
            this.tb_task_npoint = new System.Windows.Forms.TabPage();
            this.taskNpoint1 = new UI.Compment.TaskNpoint();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.CogRecordDisplay_sys = new UI.CogDisplayer();
            this.tmr_update = new System.Windows.Forms.Timer(this.components);
            this.groupBox53 = new System.Windows.Forms.GroupBox();
            this.nud_UpWsChkQrCodeCnt = new System.Windows.Forms.NumericUpDown();
            this.rbtn_UpWsChkQrCodeOff = new System.Windows.Forms.RadioButton();
            this.rbtn_UpWsChkQrCodeOn = new System.Windows.Forms.RadioButton();
            this.label47 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.ctb_sys.SuspendLayout();
            this.tp_card.SuspendLayout();
            this.tp_axis.SuspendLayout();
            this.ctb_ax_sel.SuspendLayout();
            this.tp_gpio.SuspendLayout();
            this.ctb_io_type.SuspendLayout();
            this.tp_sysparm.SuspendLayout();
            this.ctb_SetParm.SuspendLayout();
            this.tp_setparm_1.SuspendLayout();
            this.groupBox44.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TestTime)).BeginInit();
            this.groupBox39.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_JigSendTime)).BeginInit();
            this.groupBox38.SuspendLayout();
            this.groupBox45.SuspendLayout();
            this.groupBox43.SuspendLayout();
            this.groupBox42.SuspendLayout();
            this.groupBox41.SuspendLayout();
            this.groupBox40.SuspendLayout();
            this.groupBox34.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ngscale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ngcode)).BeginInit();
            this.groupBox29.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.grb_safe.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_OpenDly)).BeginInit();
            this.groupBoxbarcode.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SameRowNGTipCnt)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MovUpDly)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PlaceDly)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_vschk_rofs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_vschk_xyofs)).BeginInit();
            this.groupBox18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SameNGTipCnt)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_grrtudlcnt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_grrtestcnt)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_dwCam_xt4_ofs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_dwCam_xt3_ofs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_dwCam_xt2_ofs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_dwCam_xt1_ofs)).BeginInit();
            this.grb_barcode.SuspendLayout();
            this.grb_runmode.SuspendLayout();
            this.grb_workmode.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_EquipmentMaintain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FixtrueMaintain)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GTMOfs)).BeginInit();
            this.tp_setparm_2.SuspendLayout();
            this.groupBox48.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Areaofset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DownArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_UpArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_RightArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_LeftArea)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Areaofset2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DownArea2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_UpArea2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_RightArea2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_LeftArea2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox47.SuspendLayout();
            this.groupBox46.SuspendLayout();
            this.groupBox37.SuspendLayout();
            this.groupBox36.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_okRate)).BeginInit();
            this.groupBox35.SuspendLayout();
            this.groupBox33.SuspendLayout();
            this.groupBox32.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.groupBox28.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_jig_exposure2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_jig_contrast2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_jig_brightness2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_jig_exposure1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_jig_contrast1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_jig_brightness1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ws_exposure2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tray_exposure2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ws_contrast2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ws_brightness2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tray_contrast2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tray_brightness2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ws_exposure1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tray_exposure1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ws_contrast1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ws_brightness1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tray_contrast1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tray_brightness1)).BeginInit();
            this.groupBox25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_cleaninterval)).BeginInit();
            this.groupBox27.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_offset_degree)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox52.SuspendLayout();
            this.groupBox49.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox50.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox51.SuspendLayout();
            this.tp_calc.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.ctb_cali.SuspendLayout();
            this.tb_upcam1_npoint.SuspendLayout();
            this.tb_dwcam1_to_upcam1.SuspendLayout();
            this.tb_dwcam2_to_upcam2.SuspendLayout();
            this.Tb_ComputeCenter.SuspendLayout();
            this.tb_task_npoint.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.groupBox53.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_UpWsChkQrCodeCnt)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1294, 788);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.ctb_sys);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1288, 782);
            this.panel2.TabIndex = 1;
            // 
            // ctb_sys
            // 
            this.ctb_sys.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.ctb_sys.BackColor = System.Drawing.SystemColors.Control;
            this.ctb_sys.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.ctb_sys.Controls.Add(this.tp_card);
            this.ctb_sys.Controls.Add(this.tp_axis);
            this.ctb_sys.Controls.Add(this.tp_gpio);
            this.ctb_sys.Controls.Add(this.tp_sysparm);
            this.ctb_sys.Controls.Add(this.tp_calc);
            this.ctb_sys.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctb_sys.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ctb_sys.HeaderBackColor = System.Drawing.Color.Transparent;
            this.ctb_sys.HeadSelectedBorderColor = System.Drawing.Color.Transparent;
            this.ctb_sys.ItemSize = new System.Drawing.Size(200, 200);
            this.ctb_sys.Location = new System.Drawing.Point(0, 0);
            this.ctb_sys.Multiline = true;
            this.ctb_sys.Name = "ctb_sys";
            this.ctb_sys.SelectedIndex = 0;
            this.ctb_sys.Size = new System.Drawing.Size(1288, 782);
            this.ctb_sys.TabIndex = 2;
            this.ctb_sys.SelectedIndexChanged += new System.EventHandler(this.ctb_sys_SelectedIndexChanged);
            // 
            // tp_card
            // 
            this.tp_card.Controls.Add(this.lb_card_update_ms);
            this.tp_card.Controls.Add(this.CardTable);
            this.tp_card.Location = new System.Drawing.Point(204, 4);
            this.tp_card.Name = "tp_card";
            this.tp_card.Size = new System.Drawing.Size(1080, 774);
            this.tp_card.TabIndex = 6;
            this.tp_card.Text = "板卡状态";
            this.tp_card.UseVisualStyleBackColor = true;
            // 
            // lb_card_update_ms
            // 
            this.lb_card_update_ms.AutoSize = true;
            this.lb_card_update_ms.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_card_update_ms.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lb_card_update_ms.Location = new System.Drawing.Point(1016, 22);
            this.lb_card_update_ms.Name = "lb_card_update_ms";
            this.lb_card_update_ms.Size = new System.Drawing.Size(32, 16);
            this.lb_card_update_ms.TabIndex = 23;
            this.lb_card_update_ms.Text = "0ms";
            // 
            // CardTable
            // 
            this.CardTable.BackColor = System.Drawing.Color.Transparent;
            this.CardTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CardTable.HeaderBackgColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CardTable.Location = new System.Drawing.Point(29, 42);
            this.CardTable.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CardTable.Name = "CardTable";
            this.CardTable.Size = new System.Drawing.Size(1019, 347);
            this.CardTable.TabIndex = 0;
            this.CardTable.TableAltRowColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.CardTable.TableBackgColor = System.Drawing.SystemColors.Window;
            this.CardTable.TableFontSet = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CardTable.TableRowColor = System.Drawing.SystemColors.Window;
            this.CardTable.TableRowHight = 32;
            // 
            // tp_axis
            // 
            this.tp_axis.Controls.Add(this.btn_update_card);
            this.tp_axis.Controls.Add(this.btn_stop);
            this.tp_axis.Controls.Add(this.lb_ax_update_ms);
            this.tp_axis.Controls.Add(this.ctb_ax_sel);
            this.tp_axis.Controls.Add(this.label_ax_table);
            this.tp_axis.Controls.Add(this.label10);
            this.tp_axis.Controls.Add(this.btn_load_axis_cfg);
            this.tp_axis.Controls.Add(this.btn_save_axis_cfg);
            this.tp_axis.Controls.Add(this.axisConfig);
            this.tp_axis.Controls.Add(this.axisTable);
            this.tp_axis.Location = new System.Drawing.Point(204, 4);
            this.tp_axis.Name = "tp_axis";
            this.tp_axis.Size = new System.Drawing.Size(1080, 974);
            this.tp_axis.TabIndex = 2;
            this.tp_axis.Text = "轴参数  ";
            this.tp_axis.UseVisualStyleBackColor = true;
            // 
            // btn_update_card
            // 
            this.btn_update_card.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_update_card.Location = new System.Drawing.Point(404, 778);
            this.btn_update_card.Name = "btn_update_card";
            this.btn_update_card.Size = new System.Drawing.Size(175, 71);
            this.btn_update_card.TabIndex = 26;
            this.btn_update_card.Text = "更新到控制器";
            this.btn_update_card.UseVisualStyleBackColor = false;
            this.btn_update_card.Click += new System.EventHandler(this.btn_update_card_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.BackColor = System.Drawing.Color.Gold;
            this.btn_stop.Location = new System.Drawing.Point(905, 778);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(134, 71);
            this.btn_stop.TabIndex = 25;
            this.btn_stop.Text = "停止";
            this.btn_stop.UseVisualStyleBackColor = false;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // lb_ax_update_ms
            // 
            this.lb_ax_update_ms.AutoSize = true;
            this.lb_ax_update_ms.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_ax_update_ms.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lb_ax_update_ms.Location = new System.Drawing.Point(1003, 61);
            this.lb_ax_update_ms.Name = "lb_ax_update_ms";
            this.lb_ax_update_ms.Size = new System.Drawing.Size(32, 16);
            this.lb_ax_update_ms.TabIndex = 24;
            this.lb_ax_update_ms.Text = "0ms";
            // 
            // ctb_ax_sel
            // 
            this.ctb_ax_sel.BackColor = System.Drawing.SystemColors.Control;
            this.ctb_ax_sel.BorderColor = System.Drawing.SystemColors.Control;
            this.ctb_ax_sel.Controls.Add(this.ctp_ax_udl1);
            this.ctb_ax_sel.Controls.Add(this.ctp_ax_udl2);
            this.ctb_ax_sel.Controls.Add(this.ctp_ax_lc);
            this.ctb_ax_sel.Controls.Add(this.ctp_ax_box_left);
            this.ctb_ax_sel.Controls.Add(this.ctp_ax_box_right);
            this.ctb_ax_sel.Controls.Add(this.ctp_ax_otp);
            this.ctb_ax_sel.Controls.Add(this.ctp_ax_ws);
            this.ctb_ax_sel.Controls.Add(this.ctp_ax_all);
            this.ctb_ax_sel.HeaderBackColor = System.Drawing.SystemColors.Control;
            this.ctb_ax_sel.ItemSize = new System.Drawing.Size(60, 32);
            this.ctb_ax_sel.Location = new System.Drawing.Point(12, 5);
            this.ctb_ax_sel.Name = "ctb_ax_sel";
            this.ctb_ax_sel.SelectedIndex = 0;
            this.ctb_ax_sel.Size = new System.Drawing.Size(1038, 39);
            this.ctb_ax_sel.TabIndex = 23;
            this.ctb_ax_sel.SelectedIndexChanged += new System.EventHandler(this.ctb_ax_sel_SelectedIndexChanged);
            // 
            // ctp_ax_udl1
            // 
            this.ctp_ax_udl1.Location = new System.Drawing.Point(4, 36);
            this.ctp_ax_udl1.Name = "ctp_ax_udl1";
            this.ctp_ax_udl1.Padding = new System.Windows.Forms.Padding(3);
            this.ctp_ax_udl1.Size = new System.Drawing.Size(1030, 0);
            this.ctp_ax_udl1.TabIndex = 0;
            this.ctp_ax_udl1.Text = "上下料1    ";
            this.ctp_ax_udl1.UseVisualStyleBackColor = true;
            // 
            // ctp_ax_udl2
            // 
            this.ctp_ax_udl2.Location = new System.Drawing.Point(4, 36);
            this.ctp_ax_udl2.Name = "ctp_ax_udl2";
            this.ctp_ax_udl2.Padding = new System.Windows.Forms.Padding(3);
            this.ctp_ax_udl2.Size = new System.Drawing.Size(1030, 0);
            this.ctp_ax_udl2.TabIndex = 1;
            this.ctp_ax_udl2.Text = "上下料2      ";
            this.ctp_ax_udl2.UseVisualStyleBackColor = true;
            // 
            // ctp_ax_lc
            // 
            this.ctp_ax_lc.Location = new System.Drawing.Point(4, 36);
            this.ctp_ax_lc.Name = "ctp_ax_lc";
            this.ctp_ax_lc.Size = new System.Drawing.Size(1030, 0);
            this.ctp_ax_lc.TabIndex = 10;
            this.ctp_ax_lc.Text = "料仓    ";
            this.ctp_ax_lc.UseVisualStyleBackColor = true;
            // 
            // ctp_ax_box_left
            // 
            this.ctp_ax_box_left.Location = new System.Drawing.Point(4, 36);
            this.ctp_ax_box_left.Name = "ctp_ax_box_left";
            this.ctp_ax_box_left.Size = new System.Drawing.Size(1030, 0);
            this.ctp_ax_box_left.TabIndex = 2;
            this.ctp_ax_box_left.Text = "左光箱    ";
            this.ctp_ax_box_left.UseVisualStyleBackColor = true;
            // 
            // ctp_ax_box_right
            // 
            this.ctp_ax_box_right.Location = new System.Drawing.Point(4, 36);
            this.ctp_ax_box_right.Name = "ctp_ax_box_right";
            this.ctp_ax_box_right.Size = new System.Drawing.Size(1030, 0);
            this.ctp_ax_box_right.TabIndex = 3;
            this.ctp_ax_box_right.Text = "右光箱    ";
            this.ctp_ax_box_right.UseVisualStyleBackColor = true;
            // 
            // ctp_ax_otp
            // 
            this.ctp_ax_otp.Location = new System.Drawing.Point(4, 36);
            this.ctp_ax_otp.Name = "ctp_ax_otp";
            this.ctp_ax_otp.Size = new System.Drawing.Size(1030, 0);
            this.ctp_ax_otp.TabIndex = 9;
            this.ctp_ax_otp.Text = "OTP光箱    ";
            this.ctp_ax_otp.UseVisualStyleBackColor = true;
            // 
            // ctp_ax_ws
            // 
            this.ctp_ax_ws.Location = new System.Drawing.Point(4, 36);
            this.ctp_ax_ws.Name = "ctp_ax_ws";
            this.ctp_ax_ws.Size = new System.Drawing.Size(1030, 0);
            this.ctp_ax_ws.TabIndex = 4;
            this.ctp_ax_ws.Text = "工站旋转    ";
            this.ctp_ax_ws.UseVisualStyleBackColor = true;
            // 
            // ctp_ax_all
            // 
            this.ctp_ax_all.Location = new System.Drawing.Point(4, 36);
            this.ctp_ax_all.Name = "ctp_ax_all";
            this.ctp_ax_all.Size = new System.Drawing.Size(1030, 0);
            this.ctp_ax_all.TabIndex = 8;
            this.ctp_ax_all.Text = "所有轴    ";
            this.ctp_ax_all.UseVisualStyleBackColor = true;
            // 
            // label_ax_table
            // 
            this.label_ax_table.AutoSize = true;
            this.label_ax_table.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_ax_table.ForeColor = System.Drawing.Color.Gray;
            this.label_ax_table.Location = new System.Drawing.Point(26, 61);
            this.label_ax_table.Name = "label_ax_table";
            this.label_ax_table.Size = new System.Drawing.Size(56, 16);
            this.label_ax_table.TabIndex = 22;
            this.label_ax_table.Text = "轴调试";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.ForeColor = System.Drawing.Color.Gray;
            this.label10.Location = new System.Drawing.Point(26, 421);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 16);
            this.label10.TabIndex = 21;
            this.label10.Text = "轴参数";
            // 
            // btn_load_axis_cfg
            // 
            this.btn_load_axis_cfg.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_load_axis_cfg.Location = new System.Drawing.Point(585, 778);
            this.btn_load_axis_cfg.Name = "btn_load_axis_cfg";
            this.btn_load_axis_cfg.Size = new System.Drawing.Size(134, 71);
            this.btn_load_axis_cfg.TabIndex = 20;
            this.btn_load_axis_cfg.Text = "加载";
            this.btn_load_axis_cfg.UseVisualStyleBackColor = false;
            this.btn_load_axis_cfg.Click += new System.EventHandler(this.btn_load_axis_cfg_Click);
            // 
            // btn_save_axis_cfg
            // 
            this.btn_save_axis_cfg.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_save_axis_cfg.Location = new System.Drawing.Point(725, 778);
            this.btn_save_axis_cfg.Name = "btn_save_axis_cfg";
            this.btn_save_axis_cfg.Size = new System.Drawing.Size(134, 71);
            this.btn_save_axis_cfg.TabIndex = 19;
            this.btn_save_axis_cfg.Text = "保存";
            this.btn_save_axis_cfg.UseVisualStyleBackColor = false;
            this.btn_save_axis_cfg.Click += new System.EventHandler(this.btn_save_axis_cfg_Click);
            // 
            // axisConfig
            // 
            this.axisConfig.BackColor = System.Drawing.Color.Transparent;
            this.axisConfig.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.axisConfig.HeaderBackgColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.axisConfig.Location = new System.Drawing.Point(21, 441);
            this.axisConfig.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.axisConfig.Name = "axisConfig";
            this.axisConfig.Size = new System.Drawing.Size(1018, 330);
            this.axisConfig.TabIndex = 1;
            this.axisConfig.TableAltRowColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.axisConfig.TableBackgColor = System.Drawing.SystemColors.Window;
            this.axisConfig.TableFontSet = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.axisConfig.TableRowColor = System.Drawing.SystemColors.Window;
            this.axisConfig.TableRowHight = 32;
            // 
            // axisTable
            // 
            this.axisTable.BackColor = System.Drawing.Color.Transparent;
            this.axisTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.axisTable.HeaderBackgColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.axisTable.Location = new System.Drawing.Point(21, 81);
            this.axisTable.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.axisTable.Name = "axisTable";
            this.axisTable.Size = new System.Drawing.Size(1018, 314);
            this.axisTable.TabIndex = 0;
            this.axisTable.TableAltRowColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.axisTable.TableBackgColor = System.Drawing.SystemColors.Window;
            this.axisTable.TableFontSet = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.axisTable.TableRowColor = System.Drawing.SystemColors.Window;
            this.axisTable.TableRowHight = 32;
            // 
            // tp_gpio
            // 
            this.tp_gpio.Controls.Add(this.ctb_io_type);
            this.tp_gpio.Controls.Add(this.lb_io_update_ms);
            this.tp_gpio.Controls.Add(this.cylinderTable);
            this.tp_gpio.Controls.Add(this.ioTable);
            this.tp_gpio.Location = new System.Drawing.Point(204, 4);
            this.tp_gpio.Name = "tp_gpio";
            this.tp_gpio.Padding = new System.Windows.Forms.Padding(3);
            this.tp_gpio.Size = new System.Drawing.Size(1080, 974);
            this.tp_gpio.TabIndex = 0;
            this.tp_gpio.Text = "输入输出";
            this.tp_gpio.UseVisualStyleBackColor = true;
            // 
            // ctb_io_type
            // 
            this.ctb_io_type.BackColor = System.Drawing.SystemColors.Control;
            this.ctb_io_type.BorderColor = System.Drawing.SystemColors.Control;
            this.ctb_io_type.Controls.Add(this.tp_out);
            this.ctb_io_type.Controls.Add(this.tp_in);
            this.ctb_io_type.Controls.Add(this.tp_cy);
            this.ctb_io_type.HeaderBackColor = System.Drawing.SystemColors.Control;
            this.ctb_io_type.ItemSize = new System.Drawing.Size(60, 32);
            this.ctb_io_type.Location = new System.Drawing.Point(29, 8);
            this.ctb_io_type.Name = "ctb_io_type";
            this.ctb_io_type.SelectedIndex = 0;
            this.ctb_io_type.Size = new System.Drawing.Size(973, 39);
            this.ctb_io_type.TabIndex = 27;
            this.ctb_io_type.SelectedIndexChanged += new System.EventHandler(this.ctb_io_type_SelectedIndexChanged);
            // 
            // tp_out
            // 
            this.tp_out.Location = new System.Drawing.Point(4, 36);
            this.tp_out.Name = "tp_out";
            this.tp_out.Padding = new System.Windows.Forms.Padding(3);
            this.tp_out.Size = new System.Drawing.Size(965, 0);
            this.tp_out.TabIndex = 0;
            this.tp_out.Text = "输出      ";
            this.tp_out.UseVisualStyleBackColor = true;
            // 
            // tp_in
            // 
            this.tp_in.Location = new System.Drawing.Point(4, 36);
            this.tp_in.Name = "tp_in";
            this.tp_in.Padding = new System.Windows.Forms.Padding(3);
            this.tp_in.Size = new System.Drawing.Size(965, 0);
            this.tp_in.TabIndex = 1;
            this.tp_in.Text = "输入      ";
            this.tp_in.UseVisualStyleBackColor = true;
            // 
            // tp_cy
            // 
            this.tp_cy.Location = new System.Drawing.Point(4, 36);
            this.tp_cy.Name = "tp_cy";
            this.tp_cy.Size = new System.Drawing.Size(965, 0);
            this.tp_cy.TabIndex = 2;
            this.tp_cy.Text = "气缸/组合      ";
            this.tp_cy.UseVisualStyleBackColor = true;
            // 
            // lb_io_update_ms
            // 
            this.lb_io_update_ms.AutoSize = true;
            this.lb_io_update_ms.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_io_update_ms.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lb_io_update_ms.Location = new System.Drawing.Point(1008, 28);
            this.lb_io_update_ms.Name = "lb_io_update_ms";
            this.lb_io_update_ms.Size = new System.Drawing.Size(32, 16);
            this.lb_io_update_ms.TabIndex = 25;
            this.lb_io_update_ms.Text = "0ms";
            // 
            // cylinderTable
            // 
            this.cylinderTable.BackColor = System.Drawing.Color.Transparent;
            this.cylinderTable.color_in_on = System.Drawing.Color.Orange;
            this.cylinderTable.color_out_on = System.Drawing.Color.Lime;
            this.cylinderTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cylinderTable.HeaderBackgColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.cylinderTable.Location = new System.Drawing.Point(30, 114);
            this.cylinderTable.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cylinderTable.Name = "cylinderTable";
            this.cylinderTable.Size = new System.Drawing.Size(706, 303);
            this.cylinderTable.TabIndex = 20;
            this.cylinderTable.TableAltRowColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.cylinderTable.TableBackgColor = System.Drawing.SystemColors.Window;
            this.cylinderTable.TableFontSet = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cylinderTable.TableRowColor = System.Drawing.SystemColors.Window;
            this.cylinderTable.TableRowHight = 32;
            this.cylinderTable.Visible = false;
            // 
            // ioTable
            // 
            this.ioTable.BackColor = System.Drawing.Color.Transparent;
            this.ioTable.color_in_on = System.Drawing.Color.Orange;
            this.ioTable.color_out_on = System.Drawing.Color.Lime;
            this.ioTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ioTable.HeaderBackgColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ioTable.Location = new System.Drawing.Point(30, 60);
            this.ioTable.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ioTable.Name = "ioTable";
            this.ioTable.Size = new System.Drawing.Size(972, 780);
            this.ioTable.TabIndex = 19;
            this.ioTable.TableAltRowColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.ioTable.TableBackgColor = System.Drawing.SystemColors.Window;
            this.ioTable.TableFontSet = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ioTable.TableRowColor = System.Drawing.SystemColors.Window;
            this.ioTable.TableRowHight = 32;
            // 
            // tp_sysparm
            // 
            this.tp_sysparm.Controls.Add(this.ctb_SetParm);
            this.tp_sysparm.Location = new System.Drawing.Point(204, 4);
            this.tp_sysparm.Name = "tp_sysparm";
            this.tp_sysparm.Size = new System.Drawing.Size(1080, 774);
            this.tp_sysparm.TabIndex = 4;
            this.tp_sysparm.Text = "参数设置";
            this.tp_sysparm.UseVisualStyleBackColor = true;
            // 
            // ctb_SetParm
            // 
            this.ctb_SetParm.BackColor = System.Drawing.SystemColors.Control;
            this.ctb_SetParm.BorderColor = System.Drawing.SystemColors.Control;
            this.ctb_SetParm.Controls.Add(this.tp_setparm_1);
            this.ctb_SetParm.Controls.Add(this.tp_setparm_2);
            this.ctb_SetParm.Controls.Add(this.tabPage3);
            this.ctb_SetParm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctb_SetParm.HeaderBackColor = System.Drawing.SystemColors.Control;
            this.ctb_SetParm.HeadSelectedBackColor = System.Drawing.Color.MediumOrchid;
            this.ctb_SetParm.HeadSelectedBorderColor = System.Drawing.Color.MediumOrchid;
            this.ctb_SetParm.ItemSize = new System.Drawing.Size(80, 40);
            this.ctb_SetParm.Location = new System.Drawing.Point(0, 0);
            this.ctb_SetParm.Name = "ctb_SetParm";
            this.ctb_SetParm.SelectedIndex = 0;
            this.ctb_SetParm.Size = new System.Drawing.Size(1080, 774);
            this.ctb_SetParm.TabIndex = 132;
            // 
            // tp_setparm_1
            // 
            this.tp_setparm_1.Controls.Add(this.groupBox44);
            this.tp_setparm_1.Controls.Add(this.groupBox39);
            this.tp_setparm_1.Controls.Add(this.groupBox38);
            this.tp_setparm_1.Controls.Add(this.groupBox34);
            this.tp_setparm_1.Controls.Add(this.groupBox29);
            this.tp_setparm_1.Controls.Add(this.groupBox19);
            this.tp_setparm_1.Controls.Add(this.groupBox4);
            this.tp_setparm_1.Controls.Add(this.grb_safe);
            this.tp_setparm_1.Controls.Add(this.groupBox14);
            this.tp_setparm_1.Controls.Add(this.groupBoxbarcode);
            this.tp_setparm_1.Controls.Add(this.groupBox16);
            this.tp_setparm_1.Controls.Add(this.groupBox15);
            this.tp_setparm_1.Controls.Add(this.groupBox20);
            this.tp_setparm_1.Controls.Add(this.btn_ptset_save);
            this.tp_setparm_1.Controls.Add(this.groupBox1);
            this.tp_setparm_1.Controls.Add(this.groupBox6);
            this.tp_setparm_1.Controls.Add(this.groupBox18);
            this.tp_setparm_1.Controls.Add(this.groupBox5);
            this.tp_setparm_1.Controls.Add(this.groupBox8);
            this.tp_setparm_1.Controls.Add(this.grb_barcode);
            this.tp_setparm_1.Controls.Add(this.grb_runmode);
            this.tp_setparm_1.Controls.Add(this.grb_workmode);
            this.tp_setparm_1.Controls.Add(this.groupBox11);
            this.tp_setparm_1.Controls.Add(this.groupBox10);
            this.tp_setparm_1.Location = new System.Drawing.Point(4, 44);
            this.tp_setparm_1.Name = "tp_setparm_1";
            this.tp_setparm_1.Padding = new System.Windows.Forms.Padding(3);
            this.tp_setparm_1.Size = new System.Drawing.Size(1072, 726);
            this.tp_setparm_1.TabIndex = 0;
            this.tp_setparm_1.Text = "参数1(常用)      ";
            this.tp_setparm_1.UseVisualStyleBackColor = true;
            // 
            // groupBox44
            // 
            this.groupBox44.Controls.Add(this.nud_TestTime);
            this.groupBox44.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox44.Location = new System.Drawing.Point(649, 710);
            this.groupBox44.Name = "groupBox44";
            this.groupBox44.Size = new System.Drawing.Size(166, 67);
            this.groupBox44.TabIndex = 146;
            this.groupBox44.TabStop = false;
            this.groupBox44.Text = "最大测试时间（豪秒）";
            // 
            // nud_TestTime
            // 
            this.nud_TestTime.DecimalPlaces = 1;
            this.nud_TestTime.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_TestTime.Location = new System.Drawing.Point(6, 30);
            this.nud_TestTime.Maximum = new decimal(new int[] {
            90000000,
            0,
            0,
            0});
            this.nud_TestTime.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_TestTime.Name = "nud_TestTime";
            this.nud_TestTime.Size = new System.Drawing.Size(144, 32);
            this.nud_TestTime.TabIndex = 134;
            this.nud_TestTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_TestTime.Value = new decimal(new int[] {
            30001,
            0,
            0,
            0});
            // 
            // groupBox39
            // 
            this.groupBox39.Controls.Add(this.nud_JigSendTime);
            this.groupBox39.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox39.Location = new System.Drawing.Point(469, 710);
            this.groupBox39.Name = "groupBox39";
            this.groupBox39.Size = new System.Drawing.Size(166, 67);
            this.groupBox39.TabIndex = 145;
            this.groupBox39.TabStop = false;
            this.groupBox39.Text = "夹具上报频次（分钟）";
            // 
            // nud_JigSendTime
            // 
            this.nud_JigSendTime.DecimalPlaces = 1;
            this.nud_JigSendTime.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_JigSendTime.Location = new System.Drawing.Point(32, 30);
            this.nud_JigSendTime.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nud_JigSendTime.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_JigSendTime.Name = "nud_JigSendTime";
            this.nud_JigSendTime.Size = new System.Drawing.Size(73, 32);
            this.nud_JigSendTime.TabIndex = 134;
            this.nud_JigSendTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_JigSendTime.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // groupBox38
            // 
            this.groupBox38.Controls.Add(this.groupBox45);
            this.groupBox38.Controls.Add(this.groupBox43);
            this.groupBox38.Controls.Add(this.groupBox42);
            this.groupBox38.Controls.Add(this.groupBox41);
            this.groupBox38.Controls.Add(this.groupBox40);
            this.groupBox38.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox38.Location = new System.Drawing.Point(30, 706);
            this.groupBox38.Name = "groupBox38";
            this.groupBox38.Size = new System.Drawing.Size(399, 117);
            this.groupBox38.TabIndex = 143;
            this.groupBox38.TabStop = false;
            this.groupBox38.Text = "夹具扫二维码设置";
            // 
            // groupBox45
            // 
            this.groupBox45.Controls.Add(this.rabt_jigscan_ON);
            this.groupBox45.Controls.Add(this.rabt_jigscan_OFF);
            this.groupBox45.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox45.Location = new System.Drawing.Point(317, 20);
            this.groupBox45.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox45.Name = "groupBox45";
            this.groupBox45.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox45.Size = new System.Drawing.Size(67, 89);
            this.groupBox45.TabIndex = 132;
            this.groupBox45.TabStop = false;
            this.groupBox45.Text = "总开关";
            // 
            // rabt_jigscan_ON
            // 
            this.rabt_jigscan_ON.Appearance = System.Windows.Forms.Appearance.Button;
            this.rabt_jigscan_ON.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rabt_jigscan_ON.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rabt_jigscan_ON.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rabt_jigscan_ON.ForeColor = System.Drawing.Color.Black;
            this.rabt_jigscan_ON.Location = new System.Drawing.Point(5, 22);
            this.rabt_jigscan_ON.Name = "rabt_jigscan_ON";
            this.rabt_jigscan_ON.Size = new System.Drawing.Size(53, 30);
            this.rabt_jigscan_ON.TabIndex = 125;
            this.rabt_jigscan_ON.Text = "开启";
            this.rabt_jigscan_ON.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rabt_jigscan_ON.UseVisualStyleBackColor = true;
            // 
            // rabt_jigscan_OFF
            // 
            this.rabt_jigscan_OFF.Appearance = System.Windows.Forms.Appearance.Button;
            this.rabt_jigscan_OFF.Checked = true;
            this.rabt_jigscan_OFF.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rabt_jigscan_OFF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rabt_jigscan_OFF.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rabt_jigscan_OFF.ForeColor = System.Drawing.Color.Black;
            this.rabt_jigscan_OFF.Location = new System.Drawing.Point(5, 54);
            this.rabt_jigscan_OFF.Name = "rabt_jigscan_OFF";
            this.rabt_jigscan_OFF.Size = new System.Drawing.Size(53, 30);
            this.rabt_jigscan_OFF.TabIndex = 127;
            this.rabt_jigscan_OFF.TabStop = true;
            this.rabt_jigscan_OFF.Text = "关闭";
            this.rabt_jigscan_OFF.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rabt_jigscan_OFF.UseVisualStyleBackColor = true;
            // 
            // groupBox43
            // 
            this.groupBox43.Controls.Add(this.btnStartJigSan4);
            this.groupBox43.Controls.Add(this.radioButton6);
            this.groupBox43.Location = new System.Drawing.Point(239, 18);
            this.groupBox43.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox43.Name = "groupBox43";
            this.groupBox43.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox43.Size = new System.Drawing.Size(67, 89);
            this.groupBox43.TabIndex = 129;
            this.groupBox43.TabStop = false;
            this.groupBox43.Text = "ws4";
            // 
            // btnStartJigSan4
            // 
            this.btnStartJigSan4.Appearance = System.Windows.Forms.Appearance.Button;
            this.btnStartJigSan4.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.btnStartJigSan4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStartJigSan4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnStartJigSan4.ForeColor = System.Drawing.Color.Black;
            this.btnStartJigSan4.Location = new System.Drawing.Point(5, 22);
            this.btnStartJigSan4.Name = "btnStartJigSan4";
            this.btnStartJigSan4.Size = new System.Drawing.Size(53, 30);
            this.btnStartJigSan4.TabIndex = 125;
            this.btnStartJigSan4.Text = "开启";
            this.btnStartJigSan4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnStartJigSan4.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButton6.Checked = true;
            this.radioButton6.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.radioButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radioButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.radioButton6.ForeColor = System.Drawing.Color.Black;
            this.radioButton6.Location = new System.Drawing.Point(5, 54);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(53, 30);
            this.radioButton6.TabIndex = 127;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "关闭";
            this.radioButton6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // groupBox42
            // 
            this.groupBox42.Controls.Add(this.btnStartJigSan3);
            this.groupBox42.Controls.Add(this.radioButton4);
            this.groupBox42.Location = new System.Drawing.Point(162, 18);
            this.groupBox42.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox42.Name = "groupBox42";
            this.groupBox42.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox42.Size = new System.Drawing.Size(67, 89);
            this.groupBox42.TabIndex = 130;
            this.groupBox42.TabStop = false;
            this.groupBox42.Text = "ws3";
            // 
            // btnStartJigSan3
            // 
            this.btnStartJigSan3.Appearance = System.Windows.Forms.Appearance.Button;
            this.btnStartJigSan3.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.btnStartJigSan3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStartJigSan3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnStartJigSan3.ForeColor = System.Drawing.Color.Black;
            this.btnStartJigSan3.Location = new System.Drawing.Point(5, 22);
            this.btnStartJigSan3.Name = "btnStartJigSan3";
            this.btnStartJigSan3.Size = new System.Drawing.Size(53, 30);
            this.btnStartJigSan3.TabIndex = 125;
            this.btnStartJigSan3.Text = "开启";
            this.btnStartJigSan3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnStartJigSan3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButton4.Checked = true;
            this.radioButton4.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.radioButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radioButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.radioButton4.ForeColor = System.Drawing.Color.Black;
            this.radioButton4.Location = new System.Drawing.Point(5, 54);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(53, 30);
            this.radioButton4.TabIndex = 127;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "关闭";
            this.radioButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // groupBox41
            // 
            this.groupBox41.Controls.Add(this.btnStartJigSan2);
            this.groupBox41.Controls.Add(this.radioButton2);
            this.groupBox41.Location = new System.Drawing.Point(91, 18);
            this.groupBox41.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox41.Name = "groupBox41";
            this.groupBox41.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox41.Size = new System.Drawing.Size(67, 89);
            this.groupBox41.TabIndex = 129;
            this.groupBox41.TabStop = false;
            this.groupBox41.Text = "ws2";
            // 
            // btnStartJigSan2
            // 
            this.btnStartJigSan2.Appearance = System.Windows.Forms.Appearance.Button;
            this.btnStartJigSan2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.btnStartJigSan2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStartJigSan2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnStartJigSan2.ForeColor = System.Drawing.Color.Black;
            this.btnStartJigSan2.Location = new System.Drawing.Point(5, 22);
            this.btnStartJigSan2.Name = "btnStartJigSan2";
            this.btnStartJigSan2.Size = new System.Drawing.Size(53, 30);
            this.btnStartJigSan2.TabIndex = 125;
            this.btnStartJigSan2.Text = "开启";
            this.btnStartJigSan2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnStartJigSan2.UseVisualStyleBackColor = true;
            this.btnStartJigSan2.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButton2.Checked = true;
            this.radioButton2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.radioButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.radioButton2.ForeColor = System.Drawing.Color.Black;
            this.radioButton2.Location = new System.Drawing.Point(5, 54);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(53, 30);
            this.radioButton2.TabIndex = 127;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "关闭";
            this.radioButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // groupBox40
            // 
            this.groupBox40.Controls.Add(this.btnStartJigSan1);
            this.groupBox40.Controls.Add(this.btnStopJigSan);
            this.groupBox40.Location = new System.Drawing.Point(13, 18);
            this.groupBox40.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox40.Name = "groupBox40";
            this.groupBox40.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox40.Size = new System.Drawing.Size(67, 89);
            this.groupBox40.TabIndex = 128;
            this.groupBox40.TabStop = false;
            this.groupBox40.Text = "ws1";
            // 
            // btnStartJigSan1
            // 
            this.btnStartJigSan1.Appearance = System.Windows.Forms.Appearance.Button;
            this.btnStartJigSan1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.btnStartJigSan1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStartJigSan1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnStartJigSan1.ForeColor = System.Drawing.Color.Black;
            this.btnStartJigSan1.Location = new System.Drawing.Point(5, 22);
            this.btnStartJigSan1.Name = "btnStartJigSan1";
            this.btnStartJigSan1.Size = new System.Drawing.Size(53, 30);
            this.btnStartJigSan1.TabIndex = 125;
            this.btnStartJigSan1.Text = "开启";
            this.btnStartJigSan1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnStartJigSan1.UseVisualStyleBackColor = true;
            this.btnStartJigSan1.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // btnStopJigSan
            // 
            this.btnStopJigSan.Appearance = System.Windows.Forms.Appearance.Button;
            this.btnStopJigSan.Checked = true;
            this.btnStopJigSan.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.btnStopJigSan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStopJigSan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnStopJigSan.ForeColor = System.Drawing.Color.Black;
            this.btnStopJigSan.Location = new System.Drawing.Point(5, 54);
            this.btnStopJigSan.Name = "btnStopJigSan";
            this.btnStopJigSan.Size = new System.Drawing.Size(53, 30);
            this.btnStopJigSan.TabIndex = 127;
            this.btnStopJigSan.TabStop = true;
            this.btnStopJigSan.Text = "关闭";
            this.btnStopJigSan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnStopJigSan.UseVisualStyleBackColor = true;
            // 
            // groupBox34
            // 
            this.groupBox34.Controls.Add(this.nud_ngscale);
            this.groupBox34.Controls.Add(this.nud_ngcode);
            this.groupBox34.Controls.Add(this.label32);
            this.groupBox34.Controls.Add(this.label30);
            this.groupBox34.Controls.Add(this.rbtn_ngcontroldis);
            this.groupBox34.Controls.Add(this.rbtn_ngcontrolen);
            this.groupBox34.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox34.Location = new System.Drawing.Point(640, 589);
            this.groupBox34.Name = "groupBox34";
            this.groupBox34.Size = new System.Drawing.Size(393, 110);
            this.groupBox34.TabIndex = 141;
            this.groupBox34.TabStop = false;
            this.groupBox34.Text = "不良比例管控设置";
            // 
            // nud_ngscale
            // 
            this.nud_ngscale.DecimalPlaces = 1;
            this.nud_ngscale.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_ngscale.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_ngscale.Location = new System.Drawing.Point(218, 60);
            this.nud_ngscale.Name = "nud_ngscale";
            this.nud_ngscale.Size = new System.Drawing.Size(73, 32);
            this.nud_ngscale.TabIndex = 133;
            this.nud_ngscale.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_ngscale.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_ngcode
            // 
            this.nud_ngcode.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_ngcode.Location = new System.Drawing.Point(181, 20);
            this.nud_ngcode.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nud_ngcode.Name = "nud_ngcode";
            this.nud_ngcode.Size = new System.Drawing.Size(73, 32);
            this.nud_ngcode.TabIndex = 131;
            this.nud_ngcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_ngcode.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(135, 70);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(77, 14);
            this.label32.TabIndex = 130;
            this.label32.Text = "比例（%）:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(135, 30);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(42, 14);
            this.label30.TabIndex = 128;
            this.label30.Text = "NG码:";
            // 
            // rbtn_ngcontroldis
            // 
            this.rbtn_ngcontroldis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_ngcontroldis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_ngcontroldis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_ngcontroldis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_ngcontroldis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_ngcontroldis.Location = new System.Drawing.Point(15, 62);
            this.rbtn_ngcontroldis.Name = "rbtn_ngcontroldis";
            this.rbtn_ngcontroldis.Size = new System.Drawing.Size(97, 30);
            this.rbtn_ngcontroldis.TabIndex = 127;
            this.rbtn_ngcontroldis.Text = "关闭";
            this.rbtn_ngcontroldis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_ngcontroldis.UseVisualStyleBackColor = true;
            // 
            // rbtn_ngcontrolen
            // 
            this.rbtn_ngcontrolen.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_ngcontrolen.Checked = true;
            this.rbtn_ngcontrolen.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_ngcontrolen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_ngcontrolen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_ngcontrolen.ForeColor = System.Drawing.Color.Black;
            this.rbtn_ngcontrolen.Location = new System.Drawing.Point(15, 22);
            this.rbtn_ngcontrolen.Name = "rbtn_ngcontrolen";
            this.rbtn_ngcontrolen.Size = new System.Drawing.Size(97, 30);
            this.rbtn_ngcontrolen.TabIndex = 125;
            this.rbtn_ngcontrolen.TabStop = true;
            this.rbtn_ngcontrolen.Text = "开启";
            this.rbtn_ngcontrolen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_ngcontrolen.UseVisualStyleBackColor = true;
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.rbtn_OkCheckDis);
            this.groupBox29.Controls.Add(this.rbtn_OkCheckEn);
            this.groupBox29.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox29.Location = new System.Drawing.Point(269, 474);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(209, 108);
            this.groupBox29.TabIndex = 140;
            this.groupBox29.TabStop = false;
            this.groupBox29.Text = "下料OK品检测设置";
            // 
            // rbtn_OkCheckDis
            // 
            this.rbtn_OkCheckDis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_OkCheckDis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_OkCheckDis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_OkCheckDis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_OkCheckDis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_OkCheckDis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_OkCheckDis.Name = "rbtn_OkCheckDis";
            this.rbtn_OkCheckDis.Size = new System.Drawing.Size(155, 30);
            this.rbtn_OkCheckDis.TabIndex = 126;
            this.rbtn_OkCheckDis.Text = "关闭";
            this.rbtn_OkCheckDis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_OkCheckDis.UseVisualStyleBackColor = true;
            // 
            // rbtn_OkCheckEn
            // 
            this.rbtn_OkCheckEn.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_OkCheckEn.Checked = true;
            this.rbtn_OkCheckEn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_OkCheckEn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_OkCheckEn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_OkCheckEn.ForeColor = System.Drawing.Color.Black;
            this.rbtn_OkCheckEn.Location = new System.Drawing.Point(27, 25);
            this.rbtn_OkCheckEn.Name = "rbtn_OkCheckEn";
            this.rbtn_OkCheckEn.Size = new System.Drawing.Size(155, 30);
            this.rbtn_OkCheckEn.TabIndex = 124;
            this.rbtn_OkCheckEn.TabStop = true;
            this.rbtn_OkCheckEn.Text = "开启";
            this.rbtn_OkCheckEn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_OkCheckEn.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.chk_UpLoadData);
            this.groupBox19.Controls.Add(this.chk_UpdateSoft);
            this.groupBox19.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox19.Location = new System.Drawing.Point(512, 474);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(195, 108);
            this.groupBox19.TabIndex = 139;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "数据上传设置";
            // 
            // chk_UpLoadData
            // 
            this.chk_UpLoadData.AutoSize = true;
            this.chk_UpLoadData.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.chk_UpLoadData.Location = new System.Drawing.Point(35, 69);
            this.chk_UpLoadData.Name = "chk_UpLoadData";
            this.chk_UpLoadData.Size = new System.Drawing.Size(123, 20);
            this.chk_UpLoadData.TabIndex = 2;
            this.chk_UpLoadData.Text = "设备数据上传";
            this.chk_UpLoadData.UseVisualStyleBackColor = true;
            // 
            // chk_UpdateSoft
            // 
            this.chk_UpdateSoft.AutoSize = true;
            this.chk_UpdateSoft.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.chk_UpdateSoft.Location = new System.Drawing.Point(36, 32);
            this.chk_UpdateSoft.Name = "chk_UpdateSoft";
            this.chk_UpdateSoft.Size = new System.Drawing.Size(123, 20);
            this.chk_UpdateSoft.TabIndex = 1;
            this.chk_UpdateSoft.Text = "软件更新提示";
            this.chk_UpdateSoft.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.chk_dwcam2);
            this.groupBox4.Controls.Add(this.chk_upcam2);
            this.groupBox4.Controls.Add(this.chk_dwcam1);
            this.groupBox4.Controls.Add(this.chk_upcam1);
            this.groupBox4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox4.Location = new System.Drawing.Point(753, 474);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(280, 108);
            this.groupBox4.TabIndex = 137;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "图片存储设置";
            // 
            // chk_dwcam2
            // 
            this.chk_dwcam2.AutoSize = true;
            this.chk_dwcam2.Location = new System.Drawing.Point(160, 70);
            this.chk_dwcam2.Name = "chk_dwcam2";
            this.chk_dwcam2.Size = new System.Drawing.Size(75, 18);
            this.chk_dwcam2.TabIndex = 3;
            this.chk_dwcam2.Text = "下相机2";
            this.chk_dwcam2.UseVisualStyleBackColor = true;
            // 
            // chk_upcam2
            // 
            this.chk_upcam2.AutoSize = true;
            this.chk_upcam2.Location = new System.Drawing.Point(160, 30);
            this.chk_upcam2.Name = "chk_upcam2";
            this.chk_upcam2.Size = new System.Drawing.Size(75, 18);
            this.chk_upcam2.TabIndex = 2;
            this.chk_upcam2.Text = "上相机2";
            this.chk_upcam2.UseVisualStyleBackColor = true;
            // 
            // chk_dwcam1
            // 
            this.chk_dwcam1.AutoSize = true;
            this.chk_dwcam1.Location = new System.Drawing.Point(25, 70);
            this.chk_dwcam1.Name = "chk_dwcam1";
            this.chk_dwcam1.Size = new System.Drawing.Size(75, 18);
            this.chk_dwcam1.TabIndex = 1;
            this.chk_dwcam1.Text = "下相机1";
            this.chk_dwcam1.UseVisualStyleBackColor = true;
            // 
            // chk_upcam1
            // 
            this.chk_upcam1.AutoSize = true;
            this.chk_upcam1.Location = new System.Drawing.Point(25, 30);
            this.chk_upcam1.Name = "chk_upcam1";
            this.chk_upcam1.Size = new System.Drawing.Size(75, 18);
            this.chk_upcam1.TabIndex = 0;
            this.chk_upcam1.Text = "上相机1";
            this.chk_upcam1.UseVisualStyleBackColor = true;
            // 
            // grb_safe
            // 
            this.grb_safe.Controls.Add(this.chk_rightlightbox);
            this.grb_safe.Controls.Add(this.chk_tray);
            this.grb_safe.Controls.Add(this.chk_leftlightbox);
            this.grb_safe.Controls.Add(this.chk_updown);
            this.grb_safe.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grb_safe.Location = new System.Drawing.Point(338, 589);
            this.grb_safe.Name = "grb_safe";
            this.grb_safe.Size = new System.Drawing.Size(280, 110);
            this.grb_safe.TabIndex = 136;
            this.grb_safe.TabStop = false;
            this.grb_safe.Text = "门禁开启设置";
            // 
            // chk_rightlightbox
            // 
            this.chk_rightlightbox.AutoSize = true;
            this.chk_rightlightbox.Location = new System.Drawing.Point(160, 70);
            this.chk_rightlightbox.Name = "chk_rightlightbox";
            this.chk_rightlightbox.Size = new System.Drawing.Size(103, 18);
            this.chk_rightlightbox.TabIndex = 3;
            this.chk_rightlightbox.Text = "右光箱门禁 ";
            this.chk_rightlightbox.UseVisualStyleBackColor = true;
            // 
            // chk_tray
            // 
            this.chk_tray.AutoSize = true;
            this.chk_tray.Location = new System.Drawing.Point(160, 30);
            this.chk_tray.Name = "chk_tray";
            this.chk_tray.Size = new System.Drawing.Size(82, 18);
            this.chk_tray.TabIndex = 2;
            this.chk_tray.Text = "转盘门禁";
            this.chk_tray.UseVisualStyleBackColor = true;
            // 
            // chk_leftlightbox
            // 
            this.chk_leftlightbox.AutoSize = true;
            this.chk_leftlightbox.Location = new System.Drawing.Point(25, 70);
            this.chk_leftlightbox.Name = "chk_leftlightbox";
            this.chk_leftlightbox.Size = new System.Drawing.Size(96, 18);
            this.chk_leftlightbox.TabIndex = 1;
            this.chk_leftlightbox.Text = "左光箱门禁";
            this.chk_leftlightbox.UseVisualStyleBackColor = true;
            // 
            // chk_updown
            // 
            this.chk_updown.AutoSize = true;
            this.chk_updown.Location = new System.Drawing.Point(25, 30);
            this.chk_updown.Name = "chk_updown";
            this.chk_updown.Size = new System.Drawing.Size(96, 18);
            this.chk_updown.TabIndex = 0;
            this.chk_updown.Text = "上下料门禁";
            this.chk_updown.UseVisualStyleBackColor = true;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.nud_OpenDly);
            this.groupBox14.Controls.Add(this.label16);
            this.groupBox14.Controls.Add(this.rbtn_next_turnon);
            this.groupBox14.Controls.Add(this.rbtn_pre_turnon);
            this.groupBox14.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox14.Location = new System.Drawing.Point(30, 589);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(280, 108);
            this.groupBox14.TabIndex = 138;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "开图顺序设置";
            // 
            // nud_OpenDly
            // 
            this.nud_OpenDly.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_OpenDly.Location = new System.Drawing.Point(165, 62);
            this.nud_OpenDly.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nud_OpenDly.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_OpenDly.Name = "nud_OpenDly";
            this.nud_OpenDly.Size = new System.Drawing.Size(82, 32);
            this.nud_OpenDly.TabIndex = 128;
            this.nud_OpenDly.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_OpenDly.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(165, 31);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(80, 16);
            this.label16.TabIndex = 127;
            this.label16.Text = "开图延时:";
            // 
            // rbtn_next_turnon
            // 
            this.rbtn_next_turnon.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_next_turnon.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_next_turnon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_next_turnon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_next_turnon.ForeColor = System.Drawing.Color.Black;
            this.rbtn_next_turnon.Location = new System.Drawing.Point(27, 64);
            this.rbtn_next_turnon.Name = "rbtn_next_turnon";
            this.rbtn_next_turnon.Size = new System.Drawing.Size(110, 30);
            this.rbtn_next_turnon.TabIndex = 126;
            this.rbtn_next_turnon.Text = "旋转后开图";
            this.rbtn_next_turnon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_next_turnon.UseVisualStyleBackColor = true;
            // 
            // rbtn_pre_turnon
            // 
            this.rbtn_pre_turnon.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_pre_turnon.Checked = true;
            this.rbtn_pre_turnon.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_pre_turnon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_pre_turnon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_pre_turnon.ForeColor = System.Drawing.Color.Black;
            this.rbtn_pre_turnon.Location = new System.Drawing.Point(27, 25);
            this.rbtn_pre_turnon.Name = "rbtn_pre_turnon";
            this.rbtn_pre_turnon.Size = new System.Drawing.Size(110, 30);
            this.rbtn_pre_turnon.TabIndex = 124;
            this.rbtn_pre_turnon.TabStop = true;
            this.rbtn_pre_turnon.Text = "上完料开图";
            this.rbtn_pre_turnon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_pre_turnon.UseVisualStyleBackColor = true;
            // 
            // groupBoxbarcode
            // 
            this.groupBoxbarcode.Controls.Add(this.rbtn_CloseBarCamBack);
            this.groupBoxbarcode.Controls.Add(this.rbtn_OpenBarCamBack);
            this.groupBoxbarcode.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBoxbarcode.Location = new System.Drawing.Point(30, 474);
            this.groupBoxbarcode.Name = "groupBoxbarcode";
            this.groupBoxbarcode.Size = new System.Drawing.Size(209, 108);
            this.groupBoxbarcode.TabIndex = 135;
            this.groupBoxbarcode.TabStop = false;
            this.groupBoxbarcode.Text = "二维码回检设置";
            // 
            // rbtn_CloseBarCamBack
            // 
            this.rbtn_CloseBarCamBack.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_CloseBarCamBack.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_CloseBarCamBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_CloseBarCamBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_CloseBarCamBack.ForeColor = System.Drawing.Color.Black;
            this.rbtn_CloseBarCamBack.Location = new System.Drawing.Point(27, 64);
            this.rbtn_CloseBarCamBack.Name = "rbtn_CloseBarCamBack";
            this.rbtn_CloseBarCamBack.Size = new System.Drawing.Size(155, 30);
            this.rbtn_CloseBarCamBack.TabIndex = 126;
            this.rbtn_CloseBarCamBack.Text = "关闭";
            this.rbtn_CloseBarCamBack.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_CloseBarCamBack.UseVisualStyleBackColor = true;
            // 
            // rbtn_OpenBarCamBack
            // 
            this.rbtn_OpenBarCamBack.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_OpenBarCamBack.Checked = true;
            this.rbtn_OpenBarCamBack.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_OpenBarCamBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_OpenBarCamBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_OpenBarCamBack.ForeColor = System.Drawing.Color.Black;
            this.rbtn_OpenBarCamBack.Location = new System.Drawing.Point(27, 25);
            this.rbtn_OpenBarCamBack.Name = "rbtn_OpenBarCamBack";
            this.rbtn_OpenBarCamBack.Size = new System.Drawing.Size(155, 30);
            this.rbtn_OpenBarCamBack.TabIndex = 124;
            this.rbtn_OpenBarCamBack.TabStop = true;
            this.rbtn_OpenBarCamBack.Text = "开启";
            this.rbtn_OpenBarCamBack.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_OpenBarCamBack.UseVisualStyleBackColor = true;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.rbtn_Lag);
            this.groupBox16.Controls.Add(this.rbtn_Sml);
            this.groupBox16.Controls.Add(this.rbtn_single);
            this.groupBox16.Controls.Add(this.rbtn_double);
            this.groupBox16.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox16.Location = new System.Drawing.Point(863, 355);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(170, 112);
            this.groupBox16.TabIndex = 134;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "模组开启设置";
            // 
            // rbtn_Lag
            // 
            this.rbtn_Lag.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_Lag.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_Lag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_Lag.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_Lag.ForeColor = System.Drawing.Color.Black;
            this.rbtn_Lag.Location = new System.Drawing.Point(91, 24);
            this.rbtn_Lag.Name = "rbtn_Lag";
            this.rbtn_Lag.Size = new System.Drawing.Size(66, 30);
            this.rbtn_Lag.TabIndex = 128;
            this.rbtn_Lag.Text = "9-16开";
            this.rbtn_Lag.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_Lag.UseVisualStyleBackColor = true;
            // 
            // rbtn_Sml
            // 
            this.rbtn_Sml.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_Sml.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_Sml.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_Sml.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_Sml.ForeColor = System.Drawing.Color.Black;
            this.rbtn_Sml.Location = new System.Drawing.Point(91, 69);
            this.rbtn_Sml.Name = "rbtn_Sml";
            this.rbtn_Sml.Size = new System.Drawing.Size(66, 30);
            this.rbtn_Sml.TabIndex = 129;
            this.rbtn_Sml.Text = "1-8开";
            this.rbtn_Sml.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_Sml.UseVisualStyleBackColor = true;
            // 
            // rbtn_single
            // 
            this.rbtn_single.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_single.Checked = true;
            this.rbtn_single.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_single.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_single.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_single.ForeColor = System.Drawing.Color.Black;
            this.rbtn_single.Location = new System.Drawing.Point(13, 25);
            this.rbtn_single.Name = "rbtn_single";
            this.rbtn_single.Size = new System.Drawing.Size(66, 30);
            this.rbtn_single.TabIndex = 127;
            this.rbtn_single.TabStop = true;
            this.rbtn_single.Text = "单开";
            this.rbtn_single.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_single.UseVisualStyleBackColor = true;
            // 
            // rbtn_double
            // 
            this.rbtn_double.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_double.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_double.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_double.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_double.ForeColor = System.Drawing.Color.Black;
            this.rbtn_double.Location = new System.Drawing.Point(13, 69);
            this.rbtn_double.Name = "rbtn_double";
            this.rbtn_double.Size = new System.Drawing.Size(66, 30);
            this.rbtn_double.TabIndex = 127;
            this.rbtn_double.Text = "双开";
            this.rbtn_double.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_double.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.rbtn_big);
            this.groupBox15.Controls.Add(this.rbtn_small);
            this.groupBox15.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox15.Location = new System.Drawing.Point(753, 355);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(104, 112);
            this.groupBox15.TabIndex = 133;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "模组数量";
            // 
            // rbtn_big
            // 
            this.rbtn_big.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_big.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_big.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_big.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_big.ForeColor = System.Drawing.Color.Black;
            this.rbtn_big.Location = new System.Drawing.Point(18, 67);
            this.rbtn_big.Name = "rbtn_big";
            this.rbtn_big.Size = new System.Drawing.Size(66, 30);
            this.rbtn_big.TabIndex = 126;
            this.rbtn_big.Text = "8模组";
            this.rbtn_big.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_big.UseVisualStyleBackColor = true;
            // 
            // rbtn_small
            // 
            this.rbtn_small.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_small.Checked = true;
            this.rbtn_small.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_small.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_small.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_small.ForeColor = System.Drawing.Color.Black;
            this.rbtn_small.Location = new System.Drawing.Point(18, 25);
            this.rbtn_small.Name = "rbtn_small";
            this.rbtn_small.Size = new System.Drawing.Size(66, 30);
            this.rbtn_small.TabIndex = 124;
            this.rbtn_small.TabStop = true;
            this.rbtn_small.Text = "16模组";
            this.rbtn_small.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_small.UseVisualStyleBackColor = true;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.nud_SameRowNGTipCnt);
            this.groupBox20.Controls.Add(this.label19);
            this.groupBox20.Controls.Add(this.chk_SameRowNGTip);
            this.groupBox20.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox20.Location = new System.Drawing.Point(512, 356);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(209, 111);
            this.groupBox20.TabIndex = 132;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "工站同一排连续同NG工位提示";
            // 
            // nud_SameRowNGTipCnt
            // 
            this.nud_SameRowNGTipCnt.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_SameRowNGTipCnt.Location = new System.Drawing.Point(128, 66);
            this.nud_SameRowNGTipCnt.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.nud_SameRowNGTipCnt.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_SameRowNGTipCnt.Name = "nud_SameRowNGTipCnt";
            this.nud_SameRowNGTipCnt.Size = new System.Drawing.Size(67, 32);
            this.nud_SameRowNGTipCnt.TabIndex = 38;
            this.nud_SameRowNGTipCnt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_SameRowNGTipCnt.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(19, 73);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(112, 16);
            this.label19.TabIndex = 2;
            this.label19.Text = "单排同NG个数:";
            // 
            // chk_SameRowNGTip
            // 
            this.chk_SameRowNGTip.AutoSize = true;
            this.chk_SameRowNGTip.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.chk_SameRowNGTip.Location = new System.Drawing.Point(22, 31);
            this.chk_SameRowNGTip.Name = "chk_SameRowNGTip";
            this.chk_SameRowNGTip.Size = new System.Drawing.Size(91, 20);
            this.chk_SameRowNGTip.TabIndex = 1;
            this.chk_SameRowNGTip.Text = "开启提示";
            this.chk_SameRowNGTip.UseVisualStyleBackColor = true;
            // 
            // btn_ptset_save
            // 
            this.btn_ptset_save.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ptset_save.Location = new System.Drawing.Point(898, 743);
            this.btn_ptset_save.Name = "btn_ptset_save";
            this.btn_ptset_save.Size = new System.Drawing.Size(134, 71);
            this.btn_ptset_save.TabIndex = 20;
            this.btn_ptset_save.Text = "保存";
            this.btn_ptset_save.UseVisualStyleBackColor = false;
            this.btn_ptset_save.Click += new System.EventHandler(this.btn_ptset_save_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nud_MovUpDly);
            this.groupBox1.Controls.Add(this.nud_PlaceDly);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.Chk_ModPasteUp);
            this.groupBox1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(271, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(209, 148);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "模组带起克服设置(ms)";
            // 
            // nud_MovUpDly
            // 
            this.nud_MovUpDly.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_MovUpDly.Location = new System.Drawing.Point(109, 104);
            this.nud_MovUpDly.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nud_MovUpDly.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_MovUpDly.Name = "nud_MovUpDly";
            this.nud_MovUpDly.Size = new System.Drawing.Size(82, 32);
            this.nud_MovUpDly.TabIndex = 39;
            this.nud_MovUpDly.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_MovUpDly.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // nud_PlaceDly
            // 
            this.nud_PlaceDly.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_PlaceDly.Location = new System.Drawing.Point(109, 66);
            this.nud_PlaceDly.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nud_PlaceDly.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_PlaceDly.Name = "nud_PlaceDly";
            this.nud_PlaceDly.Size = new System.Drawing.Size(82, 32);
            this.nud_PlaceDly.TabIndex = 38;
            this.nud_PlaceDly.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_PlaceDly.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(23, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 16);
            this.label5.TabIndex = 3;
            this.label5.Text = "提起延时:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(24, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "放料延时:";
            // 
            // Chk_ModPasteUp
            // 
            this.Chk_ModPasteUp.AutoSize = true;
            this.Chk_ModPasteUp.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Chk_ModPasteUp.Location = new System.Drawing.Point(27, 31);
            this.Chk_ModPasteUp.Name = "Chk_ModPasteUp";
            this.Chk_ModPasteUp.Size = new System.Drawing.Size(155, 20);
            this.Chk_ModPasteUp.TabIndex = 1;
            this.Chk_ModPasteUp.Text = "克服模组带起开启";
            this.Chk_ModPasteUp.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.nud_vschk_rofs);
            this.groupBox6.Controls.Add(this.nud_vschk_xyofs);
            this.groupBox6.Controls.Add(this.label3);
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.Chk_OpenVs);
            this.groupBox6.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox6.Location = new System.Drawing.Point(30, 20);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(209, 148);
            this.groupBox6.TabIndex = 28;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "模组放好回检设置";
            // 
            // nud_vschk_rofs
            // 
            this.nud_vschk_rofs.DecimalPlaces = 1;
            this.nud_vschk_rofs.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_vschk_rofs.Location = new System.Drawing.Point(123, 108);
            this.nud_vschk_rofs.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_vschk_rofs.Name = "nud_vschk_rofs";
            this.nud_vschk_rofs.Size = new System.Drawing.Size(80, 32);
            this.nud_vschk_rofs.TabIndex = 39;
            this.nud_vschk_rofs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_vschk_rofs.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // nud_vschk_xyofs
            // 
            this.nud_vschk_xyofs.DecimalPlaces = 1;
            this.nud_vschk_xyofs.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_vschk_xyofs.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_vschk_xyofs.Location = new System.Drawing.Point(123, 66);
            this.nud_vschk_xyofs.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nud_vschk_xyofs.Name = "nud_vschk_xyofs";
            this.nud_vschk_xyofs.Size = new System.Drawing.Size(80, 32);
            this.nud_vschk_xyofs.TabIndex = 38;
            this.nud_vschk_xyofs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_vschk_xyofs.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(30, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "R允许偏差:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(24, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "XY允许偏差:";
            // 
            // Chk_OpenVs
            // 
            this.Chk_OpenVs.AutoSize = true;
            this.Chk_OpenVs.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Chk_OpenVs.Location = new System.Drawing.Point(27, 31);
            this.Chk_OpenVs.Name = "Chk_OpenVs";
            this.Chk_OpenVs.Size = new System.Drawing.Size(155, 20);
            this.Chk_OpenVs.TabIndex = 1;
            this.Chk_OpenVs.Text = "模组放好回检开启";
            this.Chk_OpenVs.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.nud_SameNGTipCnt);
            this.groupBox18.Controls.Add(this.label18);
            this.groupBox18.Controls.Add(this.chk_SameNGTip);
            this.groupBox18.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox18.Location = new System.Drawing.Point(271, 355);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(209, 111);
            this.groupBox18.TabIndex = 130;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "同工位连续同NG提示";
            // 
            // nud_SameNGTipCnt
            // 
            this.nud_SameNGTipCnt.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_SameNGTipCnt.Location = new System.Drawing.Point(120, 67);
            this.nud_SameNGTipCnt.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_SameNGTipCnt.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_SameNGTipCnt.Name = "nud_SameNGTipCnt";
            this.nud_SameNGTipCnt.Size = new System.Drawing.Size(73, 32);
            this.nud_SameNGTipCnt.TabIndex = 38;
            this.nud_SameNGTipCnt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_SameNGTipCnt.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(19, 73);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(80, 16);
            this.label18.TabIndex = 2;
            this.label18.Text = "连续次数:";
            // 
            // chk_SameNGTip
            // 
            this.chk_SameNGTip.AutoSize = true;
            this.chk_SameNGTip.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.chk_SameNGTip.Location = new System.Drawing.Point(22, 31);
            this.chk_SameNGTip.Name = "chk_SameNGTip";
            this.chk_SameNGTip.Size = new System.Drawing.Size(91, 20);
            this.chk_SameNGTip.TabIndex = 1;
            this.chk_SameNGTip.Text = "开启提示";
            this.chk_SameNGTip.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.nud_grrtudlcnt);
            this.groupBox5.Controls.Add(this.nud_grrtestcnt);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.chk_grr);
            this.groupBox5.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox5.Location = new System.Drawing.Point(512, 20);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(209, 148);
            this.groupBox5.TabIndex = 27;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "GRR测试流程设置";
            // 
            // nud_grrtudlcnt
            // 
            this.nud_grrtudlcnt.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_grrtudlcnt.Location = new System.Drawing.Point(108, 106);
            this.nud_grrtudlcnt.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nud_grrtudlcnt.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_grrtudlcnt.Name = "nud_grrtudlcnt";
            this.nud_grrtudlcnt.Size = new System.Drawing.Size(58, 32);
            this.nud_grrtudlcnt.TabIndex = 39;
            this.nud_grrtudlcnt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_grrtudlcnt.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // nud_grrtestcnt
            // 
            this.nud_grrtestcnt.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_grrtestcnt.Location = new System.Drawing.Point(108, 65);
            this.nud_grrtestcnt.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nud_grrtestcnt.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_grrtestcnt.Name = "nud_grrtestcnt";
            this.nud_grrtestcnt.Size = new System.Drawing.Size(58, 32);
            this.nud_grrtestcnt.TabIndex = 38;
            this.nud_grrtestcnt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_grrtestcnt.Value = new decimal(new int[] {
            11,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(23, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "轮换次数:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(24, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "测试次数:";
            // 
            // chk_grr
            // 
            this.chk_grr.AutoSize = true;
            this.chk_grr.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.chk_grr.Location = new System.Drawing.Point(27, 31);
            this.chk_grr.Name = "chk_grr";
            this.chk_grr.Size = new System.Drawing.Size(115, 20);
            this.chk_grr.TabIndex = 1;
            this.chk_grr.Text = "GRR测试开启";
            this.chk_grr.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.nud_dwCam_xt4_ofs);
            this.groupBox8.Controls.Add(this.nud_dwCam_xt3_ofs);
            this.groupBox8.Controls.Add(this.nud_dwCam_xt2_ofs);
            this.groupBox8.Controls.Add(this.nud_dwCam_xt1_ofs);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Controls.Add(this.label8);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Controls.Add(this.label9);
            this.groupBox8.Controls.Add(this.label7);
            this.groupBox8.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox8.Location = new System.Drawing.Point(753, 20);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(280, 148);
            this.groupBox8.TabIndex = 31;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "吸头下相机拍照偏移";
            // 
            // nud_dwCam_xt4_ofs
            // 
            this.nud_dwCam_xt4_ofs.DecimalPlaces = 2;
            this.nud_dwCam_xt4_ofs.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_dwCam_xt4_ofs.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_dwCam_xt4_ofs.Location = new System.Drawing.Point(155, 110);
            this.nud_dwCam_xt4_ofs.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_dwCam_xt4_ofs.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_dwCam_xt4_ofs.Name = "nud_dwCam_xt4_ofs";
            this.nud_dwCam_xt4_ofs.Size = new System.Drawing.Size(100, 32);
            this.nud_dwCam_xt4_ofs.TabIndex = 45;
            this.nud_dwCam_xt4_ofs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_dwCam_xt3_ofs
            // 
            this.nud_dwCam_xt3_ofs.DecimalPlaces = 2;
            this.nud_dwCam_xt3_ofs.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_dwCam_xt3_ofs.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_dwCam_xt3_ofs.Location = new System.Drawing.Point(15, 109);
            this.nud_dwCam_xt3_ofs.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_dwCam_xt3_ofs.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_dwCam_xt3_ofs.Name = "nud_dwCam_xt3_ofs";
            this.nud_dwCam_xt3_ofs.Size = new System.Drawing.Size(100, 32);
            this.nud_dwCam_xt3_ofs.TabIndex = 44;
            this.nud_dwCam_xt3_ofs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_dwCam_xt2_ofs
            // 
            this.nud_dwCam_xt2_ofs.DecimalPlaces = 2;
            this.nud_dwCam_xt2_ofs.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_dwCam_xt2_ofs.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_dwCam_xt2_ofs.Location = new System.Drawing.Point(155, 50);
            this.nud_dwCam_xt2_ofs.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_dwCam_xt2_ofs.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_dwCam_xt2_ofs.Name = "nud_dwCam_xt2_ofs";
            this.nud_dwCam_xt2_ofs.Size = new System.Drawing.Size(100, 32);
            this.nud_dwCam_xt2_ofs.TabIndex = 43;
            this.nud_dwCam_xt2_ofs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_dwCam_xt1_ofs
            // 
            this.nud_dwCam_xt1_ofs.DecimalPlaces = 2;
            this.nud_dwCam_xt1_ofs.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_dwCam_xt1_ofs.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_dwCam_xt1_ofs.Location = new System.Drawing.Point(15, 48);
            this.nud_dwCam_xt1_ofs.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_dwCam_xt1_ofs.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_dwCam_xt1_ofs.Name = "nud_dwCam_xt1_ofs";
            this.nud_dwCam_xt1_ofs.Size = new System.Drawing.Size(100, 32);
            this.nud_dwCam_xt1_ofs.TabIndex = 39;
            this.nud_dwCam_xt1_ofs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(147, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 16);
            this.label11.TabIndex = 8;
            this.label11.Text = "吸头4偏移(mm):";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(6, 87);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "吸头3偏移(mm):";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(150, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 16);
            this.label12.TabIndex = 6;
            this.label12.Text = "吸头2偏移(mm):";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(155, 31);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 16);
            this.label9.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(9, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 16);
            this.label7.TabIndex = 3;
            this.label7.Text = "吸头1偏移(mm):";
            // 
            // grb_barcode
            // 
            this.grb_barcode.Controls.Add(this.rbtn_NoCap);
            this.grb_barcode.Controls.Add(this.rbtn_dwcode);
            this.grb_barcode.Controls.Add(this.rbtn_upcode);
            this.grb_barcode.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grb_barcode.Location = new System.Drawing.Point(30, 356);
            this.grb_barcode.Name = "grb_barcode";
            this.grb_barcode.Size = new System.Drawing.Size(209, 110);
            this.grb_barcode.TabIndex = 0;
            this.grb_barcode.TabStop = false;
            this.grb_barcode.Text = "二维码扫码方式";
            // 
            // rbtn_NoCap
            // 
            this.rbtn_NoCap.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_NoCap.Checked = true;
            this.rbtn_NoCap.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_NoCap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_NoCap.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_NoCap.ForeColor = System.Drawing.Color.Black;
            this.rbtn_NoCap.Location = new System.Drawing.Point(137, 42);
            this.rbtn_NoCap.Name = "rbtn_NoCap";
            this.rbtn_NoCap.Size = new System.Drawing.Size(66, 30);
            this.rbtn_NoCap.TabIndex = 126;
            this.rbtn_NoCap.TabStop = true;
            this.rbtn_NoCap.Text = "不扫码";
            this.rbtn_NoCap.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_NoCap.UseVisualStyleBackColor = true;
            // 
            // rbtn_dwcode
            // 
            this.rbtn_dwcode.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_dwcode.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_dwcode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_dwcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_dwcode.ForeColor = System.Drawing.Color.Black;
            this.rbtn_dwcode.Location = new System.Drawing.Point(27, 63);
            this.rbtn_dwcode.Name = "rbtn_dwcode";
            this.rbtn_dwcode.Size = new System.Drawing.Size(93, 30);
            this.rbtn_dwcode.TabIndex = 125;
            this.rbtn_dwcode.Text = "下相机扫码";
            this.rbtn_dwcode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_dwcode.UseVisualStyleBackColor = true;
            // 
            // rbtn_upcode
            // 
            this.rbtn_upcode.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_upcode.Checked = true;
            this.rbtn_upcode.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_upcode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_upcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_upcode.ForeColor = System.Drawing.Color.Black;
            this.rbtn_upcode.Location = new System.Drawing.Point(26, 23);
            this.rbtn_upcode.Name = "rbtn_upcode";
            this.rbtn_upcode.Size = new System.Drawing.Size(94, 30);
            this.rbtn_upcode.TabIndex = 124;
            this.rbtn_upcode.TabStop = true;
            this.rbtn_upcode.Text = "上相机扫码";
            this.rbtn_upcode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_upcode.UseVisualStyleBackColor = true;
            // 
            // grb_runmode
            // 
            this.grb_runmode.Controls.Add(this.rbtn_run_updw);
            this.grb_runmode.Controls.Add(this.rbtn_run_empty);
            this.grb_runmode.Controls.Add(this.rbtn_run_normal);
            this.grb_runmode.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grb_runmode.Location = new System.Drawing.Point(30, 188);
            this.grb_runmode.Name = "grb_runmode";
            this.grb_runmode.Size = new System.Drawing.Size(209, 148);
            this.grb_runmode.TabIndex = 22;
            this.grb_runmode.TabStop = false;
            this.grb_runmode.Text = "设备运行模式设置";
            // 
            // rbtn_run_updw
            // 
            this.rbtn_run_updw.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_run_updw.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_run_updw.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_run_updw.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_run_updw.ForeColor = System.Drawing.Color.Black;
            this.rbtn_run_updw.Location = new System.Drawing.Point(27, 64);
            this.rbtn_run_updw.Name = "rbtn_run_updw";
            this.rbtn_run_updw.Size = new System.Drawing.Size(155, 30);
            this.rbtn_run_updw.TabIndex = 126;
            this.rbtn_run_updw.Text = "有料空跑";
            this.rbtn_run_updw.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_run_updw.UseVisualStyleBackColor = true;
            // 
            // rbtn_run_empty
            // 
            this.rbtn_run_empty.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_run_empty.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_run_empty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_run_empty.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_run_empty.ForeColor = System.Drawing.Color.Black;
            this.rbtn_run_empty.Location = new System.Drawing.Point(27, 105);
            this.rbtn_run_empty.Name = "rbtn_run_empty";
            this.rbtn_run_empty.Size = new System.Drawing.Size(155, 30);
            this.rbtn_run_empty.TabIndex = 125;
            this.rbtn_run_empty.Text = "无料空跑";
            this.rbtn_run_empty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_run_empty.UseVisualStyleBackColor = true;
            // 
            // rbtn_run_normal
            // 
            this.rbtn_run_normal.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_run_normal.Checked = true;
            this.rbtn_run_normal.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_run_normal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_run_normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_run_normal.ForeColor = System.Drawing.Color.Black;
            this.rbtn_run_normal.Location = new System.Drawing.Point(27, 25);
            this.rbtn_run_normal.Name = "rbtn_run_normal";
            this.rbtn_run_normal.Size = new System.Drawing.Size(155, 30);
            this.rbtn_run_normal.TabIndex = 124;
            this.rbtn_run_normal.TabStop = true;
            this.rbtn_run_normal.Text = "生产模式";
            this.rbtn_run_normal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_run_normal.UseVisualStyleBackColor = true;
            // 
            // grb_workmode
            // 
            this.grb_workmode.Controls.Add(this.rbtn_md2);
            this.grb_workmode.Controls.Add(this.rbtn_twomd);
            this.grb_workmode.Controls.Add(this.rbtn_md1);
            this.grb_workmode.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grb_workmode.Location = new System.Drawing.Point(269, 188);
            this.grb_workmode.Name = "grb_workmode";
            this.grb_workmode.Size = new System.Drawing.Size(211, 148);
            this.grb_workmode.TabIndex = 1;
            this.grb_workmode.TabStop = false;
            this.grb_workmode.Text = "上下料运行方式";
            // 
            // rbtn_md2
            // 
            this.rbtn_md2.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_md2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_md2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_md2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_md2.ForeColor = System.Drawing.Color.Black;
            this.rbtn_md2.Location = new System.Drawing.Point(29, 105);
            this.rbtn_md2.Name = "rbtn_md2";
            this.rbtn_md2.Size = new System.Drawing.Size(155, 30);
            this.rbtn_md2.TabIndex = 126;
            this.rbtn_md2.Text = "模块2工作";
            this.rbtn_md2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_md2.UseVisualStyleBackColor = true;
            // 
            // rbtn_twomd
            // 
            this.rbtn_twomd.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_twomd.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_twomd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_twomd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_twomd.ForeColor = System.Drawing.Color.Black;
            this.rbtn_twomd.Location = new System.Drawing.Point(29, 25);
            this.rbtn_twomd.Name = "rbtn_twomd";
            this.rbtn_twomd.Size = new System.Drawing.Size(155, 30);
            this.rbtn_twomd.TabIndex = 125;
            this.rbtn_twomd.Text = "两模块协同工作";
            this.rbtn_twomd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_twomd.UseVisualStyleBackColor = true;
            // 
            // rbtn_md1
            // 
            this.rbtn_md1.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_md1.Checked = true;
            this.rbtn_md1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_md1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_md1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_md1.ForeColor = System.Drawing.Color.Black;
            this.rbtn_md1.Location = new System.Drawing.Point(29, 64);
            this.rbtn_md1.Name = "rbtn_md1";
            this.rbtn_md1.Size = new System.Drawing.Size(155, 30);
            this.rbtn_md1.TabIndex = 124;
            this.rbtn_md1.TabStop = true;
            this.rbtn_md1.Text = "模块1工作";
            this.rbtn_md1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_md1.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.nud_EquipmentMaintain);
            this.groupBox11.Controls.Add(this.nud_FixtrueMaintain);
            this.groupBox11.Controls.Add(this.label15);
            this.groupBox11.Controls.Add(this.label13);
            this.groupBox11.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox11.Location = new System.Drawing.Point(753, 188);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(280, 148);
            this.groupBox11.TabIndex = 35;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "保养提醒(次)";
            // 
            // nud_EquipmentMaintain
            // 
            this.nud_EquipmentMaintain.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_EquipmentMaintain.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_EquipmentMaintain.Location = new System.Drawing.Point(133, 88);
            this.nud_EquipmentMaintain.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nud_EquipmentMaintain.Name = "nud_EquipmentMaintain";
            this.nud_EquipmentMaintain.Size = new System.Drawing.Size(116, 32);
            this.nud_EquipmentMaintain.TabIndex = 41;
            this.nud_EquipmentMaintain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_FixtrueMaintain
            // 
            this.nud_FixtrueMaintain.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_FixtrueMaintain.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_FixtrueMaintain.Location = new System.Drawing.Point(132, 36);
            this.nud_FixtrueMaintain.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.nud_FixtrueMaintain.Name = "nud_FixtrueMaintain";
            this.nud_FixtrueMaintain.Size = new System.Drawing.Size(116, 32);
            this.nud_FixtrueMaintain.TabIndex = 40;
            this.nud_FixtrueMaintain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(15, 42);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(112, 16);
            this.label15.TabIndex = 39;
            this.label15.Text = "夹具保养频率:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(15, 95);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(112, 16);
            this.label13.TabIndex = 2;
            this.label13.Text = "设备保养频率:";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.nud_GTMOfs);
            this.groupBox10.Controls.Add(this.label14);
            this.groupBox10.Controls.Add(this.chk_GTMCheck);
            this.groupBox10.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox10.Location = new System.Drawing.Point(512, 188);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(209, 148);
            this.groupBox10.TabIndex = 34;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "高透膜偏移检测设置(mm)";
            // 
            // nud_GTMOfs
            // 
            this.nud_GTMOfs.DecimalPlaces = 2;
            this.nud_GTMOfs.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_GTMOfs.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_GTMOfs.Location = new System.Drawing.Point(109, 88);
            this.nud_GTMOfs.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            65536});
            this.nud_GTMOfs.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            65536});
            this.nud_GTMOfs.Name = "nud_GTMOfs";
            this.nud_GTMOfs.Size = new System.Drawing.Size(86, 32);
            this.nud_GTMOfs.TabIndex = 38;
            this.nud_GTMOfs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_GTMOfs.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(23, 94);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 16);
            this.label14.TabIndex = 2;
            this.label14.Text = "接受距离:";
            // 
            // chk_GTMCheck
            // 
            this.chk_GTMCheck.AutoSize = true;
            this.chk_GTMCheck.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.chk_GTMCheck.Location = new System.Drawing.Point(24, 41);
            this.chk_GTMCheck.Name = "chk_GTMCheck";
            this.chk_GTMCheck.Size = new System.Drawing.Size(171, 20);
            this.chk_GTMCheck.TabIndex = 1;
            this.chk_GTMCheck.Text = "高透模偏移检测开启";
            this.chk_GTMCheck.UseVisualStyleBackColor = true;
            // 
            // tp_setparm_2
            // 
            this.tp_setparm_2.Controls.Add(this.groupBox48);
            this.tp_setparm_2.Controls.Add(this.groupBox3);
            this.tp_setparm_2.Controls.Add(this.groupBox7);
            this.tp_setparm_2.Controls.Add(this.groupBox47);
            this.tp_setparm_2.Controls.Add(this.groupBox46);
            this.tp_setparm_2.Controls.Add(this.groupBox37);
            this.tp_setparm_2.Controls.Add(this.groupBox36);
            this.tp_setparm_2.Controls.Add(this.groupBox35);
            this.tp_setparm_2.Controls.Add(this.groupBox33);
            this.tp_setparm_2.Controls.Add(this.groupBox32);
            this.tp_setparm_2.Controls.Add(this.groupBox31);
            this.tp_setparm_2.Controls.Add(this.groupBox30);
            this.tp_setparm_2.Controls.Add(this.groupBox28);
            this.tp_setparm_2.Controls.Add(this.groupBox25);
            this.tp_setparm_2.Controls.Add(this.groupBox27);
            this.tp_setparm_2.Controls.Add(this.groupBox26);
            this.tp_setparm_2.Controls.Add(this.groupBox24);
            this.tp_setparm_2.Controls.Add(this.groupBox23);
            this.tp_setparm_2.Controls.Add(this.groupBox22);
            this.tp_setparm_2.Controls.Add(this.groupBox21);
            this.tp_setparm_2.Controls.Add(this.btn_saveparm2);
            this.tp_setparm_2.Controls.Add(this.groupBox2);
            this.tp_setparm_2.Controls.Add(this.groupBox12);
            this.tp_setparm_2.Controls.Add(this.groupBox17);
            this.tp_setparm_2.Controls.Add(this.groupBox9);
            this.tp_setparm_2.Controls.Add(this.groupBox13);
            this.tp_setparm_2.Location = new System.Drawing.Point(4, 44);
            this.tp_setparm_2.Name = "tp_setparm_2";
            this.tp_setparm_2.Padding = new System.Windows.Forms.Padding(3);
            this.tp_setparm_2.Size = new System.Drawing.Size(1072, 726);
            this.tp_setparm_2.TabIndex = 1;
            this.tp_setparm_2.Text = "参数2          ";
            this.tp_setparm_2.UseVisualStyleBackColor = true;
            // 
            // groupBox48
            // 
            this.groupBox48.Controls.Add(this.cb_ConnectorCheck);
            this.groupBox48.Controls.Add(this.tabControl1);
            this.groupBox48.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox48.Location = new System.Drawing.Point(27, 694);
            this.groupBox48.Name = "groupBox48";
            this.groupBox48.Size = new System.Drawing.Size(758, 131);
            this.groupBox48.TabIndex = 153;
            this.groupBox48.TabStop = false;
            this.groupBox48.Text = "连接器回检指标";
            // 
            // cb_ConnectorCheck
            // 
            this.cb_ConnectorCheck.AutoSize = true;
            this.cb_ConnectorCheck.Location = new System.Drawing.Point(642, 22);
            this.cb_ConnectorCheck.Name = "cb_ConnectorCheck";
            this.cb_ConnectorCheck.Size = new System.Drawing.Size(110, 18);
            this.cb_ConnectorCheck.TabIndex = 48;
            this.cb_ConnectorCheck.Text = "多链接器管控";
            this.cb_ConnectorCheck.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(9, 22);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(627, 97);
            this.tabControl1.TabIndex = 49;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.nud_Areaofset);
            this.tabPage1.Controls.Add(this.label39);
            this.tabPage1.Controls.Add(this.nud_DownArea);
            this.tabPage1.Controls.Add(this.nud_UpArea);
            this.tabPage1.Controls.Add(this.nud_RightArea);
            this.tabPage1.Controls.Add(this.nud_LeftArea);
            this.tabPage1.Controls.Add(this.label34);
            this.tabPage1.Controls.Add(this.label35);
            this.tabPage1.Controls.Add(this.label36);
            this.tabPage1.Controls.Add(this.label37);
            this.tabPage1.Controls.Add(this.label38);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(619, 69);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "1号上下料";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // nud_Areaofset
            // 
            this.nud_Areaofset.DecimalPlaces = 2;
            this.nud_Areaofset.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_Areaofset.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_Areaofset.Location = new System.Drawing.Point(463, 30);
            this.nud_Areaofset.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_Areaofset.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_Areaofset.Name = "nud_Areaofset";
            this.nud_Areaofset.Size = new System.Drawing.Size(100, 32);
            this.nud_Areaofset.TabIndex = 58;
            this.nud_Areaofset.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label39.Location = new System.Drawing.Point(460, 7);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(56, 16);
            this.label39.TabIndex = 57;
            this.label39.Text = "管控：";
            // 
            // nud_DownArea
            // 
            this.nud_DownArea.DecimalPlaces = 2;
            this.nud_DownArea.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_DownArea.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_DownArea.Location = new System.Drawing.Point(349, 30);
            this.nud_DownArea.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_DownArea.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_DownArea.Name = "nud_DownArea";
            this.nud_DownArea.Size = new System.Drawing.Size(100, 32);
            this.nud_DownArea.TabIndex = 56;
            this.nud_DownArea.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_UpArea
            // 
            this.nud_UpArea.DecimalPlaces = 2;
            this.nud_UpArea.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_UpArea.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_UpArea.Location = new System.Drawing.Point(237, 29);
            this.nud_UpArea.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_UpArea.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_UpArea.Name = "nud_UpArea";
            this.nud_UpArea.Size = new System.Drawing.Size(100, 32);
            this.nud_UpArea.TabIndex = 55;
            this.nud_UpArea.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_RightArea
            // 
            this.nud_RightArea.DecimalPlaces = 2;
            this.nud_RightArea.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_RightArea.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_RightArea.Location = new System.Drawing.Point(123, 30);
            this.nud_RightArea.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_RightArea.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_RightArea.Name = "nud_RightArea";
            this.nud_RightArea.Size = new System.Drawing.Size(100, 32);
            this.nud_RightArea.TabIndex = 54;
            this.nud_RightArea.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_LeftArea
            // 
            this.nud_LeftArea.DecimalPlaces = 2;
            this.nud_LeftArea.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_LeftArea.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_LeftArea.Location = new System.Drawing.Point(11, 28);
            this.nud_LeftArea.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_LeftArea.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_LeftArea.Name = "nud_LeftArea";
            this.nud_LeftArea.Size = new System.Drawing.Size(100, 32);
            this.nud_LeftArea.TabIndex = 53;
            this.nud_LeftArea.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.Location = new System.Drawing.Point(341, 6);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(72, 16);
            this.label34.TabIndex = 52;
            this.label34.Text = "下面积：";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.Location = new System.Drawing.Point(228, 7);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(72, 16);
            this.label35.TabIndex = 51;
            this.label35.Text = "上面积：";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.Location = new System.Drawing.Point(118, 7);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(72, 16);
            this.label36.TabIndex = 50;
            this.label36.Text = "右面积：";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.Location = new System.Drawing.Point(151, 29);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(0, 16);
            this.label37.TabIndex = 49;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label38.Location = new System.Drawing.Point(5, 7);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(72, 16);
            this.label38.TabIndex = 48;
            this.label38.Text = "左面积：";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.nud_Areaofset2);
            this.tabPage2.Controls.Add(this.label40);
            this.tabPage2.Controls.Add(this.nud_DownArea2);
            this.tabPage2.Controls.Add(this.nud_UpArea2);
            this.tabPage2.Controls.Add(this.nud_RightArea2);
            this.tabPage2.Controls.Add(this.nud_LeftArea2);
            this.tabPage2.Controls.Add(this.label41);
            this.tabPage2.Controls.Add(this.label42);
            this.tabPage2.Controls.Add(this.label43);
            this.tabPage2.Controls.Add(this.label44);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(619, 69);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "2号上下料";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // nud_Areaofset2
            // 
            this.nud_Areaofset2.DecimalPlaces = 2;
            this.nud_Areaofset2.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_Areaofset2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_Areaofset2.Location = new System.Drawing.Point(460, 30);
            this.nud_Areaofset2.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_Areaofset2.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_Areaofset2.Name = "nud_Areaofset2";
            this.nud_Areaofset2.Size = new System.Drawing.Size(100, 32);
            this.nud_Areaofset2.TabIndex = 68;
            this.nud_Areaofset2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label40.Location = new System.Drawing.Point(457, 7);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(56, 16);
            this.label40.TabIndex = 67;
            this.label40.Text = "管控：";
            // 
            // nud_DownArea2
            // 
            this.nud_DownArea2.DecimalPlaces = 2;
            this.nud_DownArea2.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_DownArea2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_DownArea2.Location = new System.Drawing.Point(349, 30);
            this.nud_DownArea2.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_DownArea2.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_DownArea2.Name = "nud_DownArea2";
            this.nud_DownArea2.Size = new System.Drawing.Size(100, 32);
            this.nud_DownArea2.TabIndex = 66;
            this.nud_DownArea2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_UpArea2
            // 
            this.nud_UpArea2.DecimalPlaces = 2;
            this.nud_UpArea2.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_UpArea2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_UpArea2.Location = new System.Drawing.Point(237, 29);
            this.nud_UpArea2.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_UpArea2.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_UpArea2.Name = "nud_UpArea2";
            this.nud_UpArea2.Size = new System.Drawing.Size(100, 32);
            this.nud_UpArea2.TabIndex = 65;
            this.nud_UpArea2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_RightArea2
            // 
            this.nud_RightArea2.DecimalPlaces = 2;
            this.nud_RightArea2.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_RightArea2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_RightArea2.Location = new System.Drawing.Point(123, 30);
            this.nud_RightArea2.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_RightArea2.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_RightArea2.Name = "nud_RightArea2";
            this.nud_RightArea2.Size = new System.Drawing.Size(100, 32);
            this.nud_RightArea2.TabIndex = 64;
            this.nud_RightArea2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_LeftArea2
            // 
            this.nud_LeftArea2.DecimalPlaces = 2;
            this.nud_LeftArea2.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_LeftArea2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_LeftArea2.Location = new System.Drawing.Point(11, 28);
            this.nud_LeftArea2.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_LeftArea2.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.nud_LeftArea2.Name = "nud_LeftArea2";
            this.nud_LeftArea2.Size = new System.Drawing.Size(100, 32);
            this.nud_LeftArea2.TabIndex = 63;
            this.nud_LeftArea2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label41.Location = new System.Drawing.Point(341, 6);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(72, 16);
            this.label41.TabIndex = 62;
            this.label41.Text = "下面积：";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label42.Location = new System.Drawing.Point(228, 7);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(72, 16);
            this.label42.TabIndex = 61;
            this.label42.Text = "上面积：";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label43.Location = new System.Drawing.Point(118, 7);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(72, 16);
            this.label43.TabIndex = 60;
            this.label43.Text = "右面积：";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label44.Location = new System.Drawing.Point(5, 7);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(72, 16);
            this.label44.TabIndex = 59;
            this.label44.Text = "左面积：";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rad_light_xsj);
            this.groupBox3.Controls.Add(this.rad_G4C);
            this.groupBox3.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox3.Location = new System.Drawing.Point(349, 21);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(143, 110);
            this.groupBox3.TabIndex = 152;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "光源切换";
            // 
            // rad_light_xsj
            // 
            this.rad_light_xsj.Appearance = System.Windows.Forms.Appearance.Button;
            this.rad_light_xsj.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rad_light_xsj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rad_light_xsj.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rad_light_xsj.ForeColor = System.Drawing.Color.Black;
            this.rad_light_xsj.Location = new System.Drawing.Point(25, 74);
            this.rad_light_xsj.Name = "rad_light_xsj";
            this.rad_light_xsj.Size = new System.Drawing.Size(87, 30);
            this.rad_light_xsj.TabIndex = 126;
            this.rad_light_xsj.Text = "轩仕佳";
            this.rad_light_xsj.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad_light_xsj.UseVisualStyleBackColor = true;
            // 
            // rad_G4C
            // 
            this.rad_G4C.Appearance = System.Windows.Forms.Appearance.Button;
            this.rad_G4C.Checked = true;
            this.rad_G4C.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rad_G4C.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rad_G4C.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rad_G4C.ForeColor = System.Drawing.Color.Black;
            this.rad_G4C.Location = new System.Drawing.Point(25, 31);
            this.rad_G4C.Name = "rad_G4C";
            this.rad_G4C.Size = new System.Drawing.Size(87, 30);
            this.rad_G4C.TabIndex = 124;
            this.rad_G4C.TabStop = true;
            this.rad_G4C.Text = "G4C";
            this.rad_G4C.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad_G4C.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.rbtn_Y1dis);
            this.groupBox7.Controls.Add(this.rbtn_Y1en);
            this.groupBox7.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox7.Location = new System.Drawing.Point(27, 21);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(146, 110);
            this.groupBox7.TabIndex = 151;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "增距镜Y1开启设置(不能变更)";
            // 
            // rbtn_Y1dis
            // 
            this.rbtn_Y1dis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_Y1dis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_Y1dis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_Y1dis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_Y1dis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_Y1dis.Location = new System.Drawing.Point(27, 74);
            this.rbtn_Y1dis.Name = "rbtn_Y1dis";
            this.rbtn_Y1dis.Size = new System.Drawing.Size(83, 30);
            this.rbtn_Y1dis.TabIndex = 126;
            this.rbtn_Y1dis.Text = "关闭Y1";
            this.rbtn_Y1dis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_Y1dis.UseVisualStyleBackColor = true;
            // 
            // rbtn_Y1en
            // 
            this.rbtn_Y1en.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_Y1en.Checked = true;
            this.rbtn_Y1en.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_Y1en.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_Y1en.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_Y1en.ForeColor = System.Drawing.Color.Black;
            this.rbtn_Y1en.Location = new System.Drawing.Point(27, 38);
            this.rbtn_Y1en.Name = "rbtn_Y1en";
            this.rbtn_Y1en.Size = new System.Drawing.Size(83, 30);
            this.rbtn_Y1en.TabIndex = 124;
            this.rbtn_Y1en.TabStop = true;
            this.rbtn_Y1en.Text = "开启Y1";
            this.rbtn_Y1en.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_Y1en.UseVisualStyleBackColor = true;
            // 
            // groupBox47
            // 
            this.groupBox47.Controls.Add(this.rbtn_safeoff);
            this.groupBox47.Controls.Add(this.rbtn_safeon);
            this.groupBox47.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox47.Location = new System.Drawing.Point(200, 21);
            this.groupBox47.Name = "groupBox47";
            this.groupBox47.Size = new System.Drawing.Size(143, 110);
            this.groupBox47.TabIndex = 150;
            this.groupBox47.TabStop = false;
            this.groupBox47.Text = "上下料移动保护(针对转盘)";
            // 
            // rbtn_safeoff
            // 
            this.rbtn_safeoff.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_safeoff.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_safeoff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_safeoff.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_safeoff.ForeColor = System.Drawing.Color.Black;
            this.rbtn_safeoff.Location = new System.Drawing.Point(27, 74);
            this.rbtn_safeoff.Name = "rbtn_safeoff";
            this.rbtn_safeoff.Size = new System.Drawing.Size(87, 30);
            this.rbtn_safeoff.TabIndex = 126;
            this.rbtn_safeoff.Text = "关闭保护";
            this.rbtn_safeoff.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_safeoff.UseVisualStyleBackColor = true;
            // 
            // rbtn_safeon
            // 
            this.rbtn_safeon.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_safeon.Checked = true;
            this.rbtn_safeon.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_safeon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_safeon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_safeon.ForeColor = System.Drawing.Color.Black;
            this.rbtn_safeon.Location = new System.Drawing.Point(27, 31);
            this.rbtn_safeon.Name = "rbtn_safeon";
            this.rbtn_safeon.Size = new System.Drawing.Size(87, 30);
            this.rbtn_safeon.TabIndex = 124;
            this.rbtn_safeon.TabStop = true;
            this.rbtn_safeon.Text = "开启保护";
            this.rbtn_safeon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_safeon.UseVisualStyleBackColor = true;
            // 
            // groupBox46
            // 
            this.groupBox46.Controls.Add(this.rbtn_AddCapQrcodeDis);
            this.groupBox46.Controls.Add(this.rbtn_AddCapQrcodeEn);
            this.groupBox46.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox46.Location = new System.Drawing.Point(949, 554);
            this.groupBox46.Name = "groupBox46";
            this.groupBox46.Size = new System.Drawing.Size(117, 134);
            this.groupBox46.TabIndex = 149;
            this.groupBox46.TabStop = false;
            this.groupBox46.Text = "新增上拍扫二维码位";
            // 
            // rbtn_AddCapQrcodeDis
            // 
            this.rbtn_AddCapQrcodeDis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_AddCapQrcodeDis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_AddCapQrcodeDis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_AddCapQrcodeDis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_AddCapQrcodeDis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_AddCapQrcodeDis.Location = new System.Drawing.Point(18, 86);
            this.rbtn_AddCapQrcodeDis.Name = "rbtn_AddCapQrcodeDis";
            this.rbtn_AddCapQrcodeDis.Size = new System.Drawing.Size(84, 30);
            this.rbtn_AddCapQrcodeDis.TabIndex = 126;
            this.rbtn_AddCapQrcodeDis.Text = "关闭";
            this.rbtn_AddCapQrcodeDis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_AddCapQrcodeDis.UseVisualStyleBackColor = true;
            // 
            // rbtn_AddCapQrcodeEn
            // 
            this.rbtn_AddCapQrcodeEn.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_AddCapQrcodeEn.Checked = true;
            this.rbtn_AddCapQrcodeEn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_AddCapQrcodeEn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_AddCapQrcodeEn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_AddCapQrcodeEn.ForeColor = System.Drawing.Color.Black;
            this.rbtn_AddCapQrcodeEn.Location = new System.Drawing.Point(18, 45);
            this.rbtn_AddCapQrcodeEn.Name = "rbtn_AddCapQrcodeEn";
            this.rbtn_AddCapQrcodeEn.Size = new System.Drawing.Size(84, 30);
            this.rbtn_AddCapQrcodeEn.TabIndex = 124;
            this.rbtn_AddCapQrcodeEn.TabStop = true;
            this.rbtn_AddCapQrcodeEn.Text = "开启";
            this.rbtn_AddCapQrcodeEn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_AddCapQrcodeEn.UseVisualStyleBackColor = true;
            // 
            // groupBox37
            // 
            this.groupBox37.Controls.Add(this.rbtn_MesRemote);
            this.groupBox37.Controls.Add(this.rbtn_MesLocal);
            this.groupBox37.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox37.Location = new System.Drawing.Point(949, 275);
            this.groupBox37.Name = "groupBox37";
            this.groupBox37.Size = new System.Drawing.Size(114, 110);
            this.groupBox37.TabIndex = 148;
            this.groupBox37.TabStop = false;
            this.groupBox37.Text = "Mes模式";
            // 
            // rbtn_MesRemote
            // 
            this.rbtn_MesRemote.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_MesRemote.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_MesRemote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_MesRemote.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_MesRemote.ForeColor = System.Drawing.Color.Black;
            this.rbtn_MesRemote.Location = new System.Drawing.Point(27, 64);
            this.rbtn_MesRemote.Name = "rbtn_MesRemote";
            this.rbtn_MesRemote.Size = new System.Drawing.Size(73, 30);
            this.rbtn_MesRemote.TabIndex = 126;
            this.rbtn_MesRemote.Text = "Remote";
            this.rbtn_MesRemote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_MesRemote.UseVisualStyleBackColor = true;
            // 
            // rbtn_MesLocal
            // 
            this.rbtn_MesLocal.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_MesLocal.Checked = true;
            this.rbtn_MesLocal.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_MesLocal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_MesLocal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_MesLocal.ForeColor = System.Drawing.Color.Black;
            this.rbtn_MesLocal.Location = new System.Drawing.Point(27, 24);
            this.rbtn_MesLocal.Name = "rbtn_MesLocal";
            this.rbtn_MesLocal.Size = new System.Drawing.Size(73, 30);
            this.rbtn_MesLocal.TabIndex = 124;
            this.rbtn_MesLocal.TabStop = true;
            this.rbtn_MesLocal.Text = "Local";
            this.rbtn_MesLocal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_MesLocal.UseVisualStyleBackColor = true;
            // 
            // groupBox36
            // 
            this.groupBox36.Controls.Add(this.nud_okRate);
            this.groupBox36.Controls.Add(this.rbtn_NgWarningDis);
            this.groupBox36.Controls.Add(this.rbtn_NgWarningEn);
            this.groupBox36.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox36.Location = new System.Drawing.Point(798, 535);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Size = new System.Drawing.Size(139, 153);
            this.groupBox36.TabIndex = 147;
            this.groupBox36.TabStop = false;
            this.groupBox36.Text = "良率报警设置";
            // 
            // nud_okRate
            // 
            this.nud_okRate.BackColor = System.Drawing.SystemColors.Window;
            this.nud_okRate.DecimalPlaces = 1;
            this.nud_okRate.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_okRate.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_okRate.Location = new System.Drawing.Point(27, 108);
            this.nud_okRate.Name = "nud_okRate";
            this.nud_okRate.Size = new System.Drawing.Size(82, 32);
            this.nud_okRate.TabIndex = 131;
            this.nud_okRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_okRate.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // rbtn_NgWarningDis
            // 
            this.rbtn_NgWarningDis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_NgWarningDis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_NgWarningDis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_NgWarningDis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_NgWarningDis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_NgWarningDis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_NgWarningDis.Name = "rbtn_NgWarningDis";
            this.rbtn_NgWarningDis.Size = new System.Drawing.Size(71, 30);
            this.rbtn_NgWarningDis.TabIndex = 126;
            this.rbtn_NgWarningDis.Text = "关闭";
            this.rbtn_NgWarningDis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_NgWarningDis.UseVisualStyleBackColor = true;
            // 
            // rbtn_NgWarningEn
            // 
            this.rbtn_NgWarningEn.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_NgWarningEn.Checked = true;
            this.rbtn_NgWarningEn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_NgWarningEn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_NgWarningEn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_NgWarningEn.ForeColor = System.Drawing.Color.Black;
            this.rbtn_NgWarningEn.Location = new System.Drawing.Point(27, 24);
            this.rbtn_NgWarningEn.Name = "rbtn_NgWarningEn";
            this.rbtn_NgWarningEn.Size = new System.Drawing.Size(71, 30);
            this.rbtn_NgWarningEn.TabIndex = 124;
            this.rbtn_NgWarningEn.TabStop = true;
            this.rbtn_NgWarningEn.Text = "开启";
            this.rbtn_NgWarningEn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_NgWarningEn.UseVisualStyleBackColor = true;
            // 
            // groupBox35
            // 
            this.groupBox35.Controls.Add(this.rbtn_ContinuousAlarmDis);
            this.groupBox35.Controls.Add(this.rbtn_ContinuousAlarmEn);
            this.groupBox35.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox35.Location = new System.Drawing.Point(949, 149);
            this.groupBox35.Name = "groupBox35";
            this.groupBox35.Size = new System.Drawing.Size(114, 110);
            this.groupBox35.TabIndex = 146;
            this.groupBox35.TabStop = false;
            this.groupBox35.Text = "持续报警设置";
            // 
            // rbtn_ContinuousAlarmDis
            // 
            this.rbtn_ContinuousAlarmDis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_ContinuousAlarmDis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_ContinuousAlarmDis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_ContinuousAlarmDis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_ContinuousAlarmDis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_ContinuousAlarmDis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_ContinuousAlarmDis.Name = "rbtn_ContinuousAlarmDis";
            this.rbtn_ContinuousAlarmDis.Size = new System.Drawing.Size(65, 30);
            this.rbtn_ContinuousAlarmDis.TabIndex = 126;
            this.rbtn_ContinuousAlarmDis.Text = "关闭";
            this.rbtn_ContinuousAlarmDis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_ContinuousAlarmDis.UseVisualStyleBackColor = true;
            // 
            // rbtn_ContinuousAlarmEn
            // 
            this.rbtn_ContinuousAlarmEn.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_ContinuousAlarmEn.Checked = true;
            this.rbtn_ContinuousAlarmEn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_ContinuousAlarmEn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_ContinuousAlarmEn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_ContinuousAlarmEn.ForeColor = System.Drawing.Color.Black;
            this.rbtn_ContinuousAlarmEn.Location = new System.Drawing.Point(27, 24);
            this.rbtn_ContinuousAlarmEn.Name = "rbtn_ContinuousAlarmEn";
            this.rbtn_ContinuousAlarmEn.Size = new System.Drawing.Size(65, 30);
            this.rbtn_ContinuousAlarmEn.TabIndex = 124;
            this.rbtn_ContinuousAlarmEn.TabStop = true;
            this.rbtn_ContinuousAlarmEn.Text = "开启";
            this.rbtn_ContinuousAlarmEn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_ContinuousAlarmEn.UseVisualStyleBackColor = true;
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.rbtn_delaytestdis);
            this.groupBox33.Controls.Add(this.rbtn_delaytesten);
            this.groupBox33.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox33.Location = new System.Drawing.Point(641, 535);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(146, 110);
            this.groupBox33.TabIndex = 145;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "DCC数据处理移至上下料";
            // 
            // rbtn_delaytestdis
            // 
            this.rbtn_delaytestdis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_delaytestdis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_delaytestdis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_delaytestdis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_delaytestdis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_delaytestdis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_delaytestdis.Name = "rbtn_delaytestdis";
            this.rbtn_delaytestdis.Size = new System.Drawing.Size(83, 30);
            this.rbtn_delaytestdis.TabIndex = 126;
            this.rbtn_delaytestdis.Text = "关闭";
            this.rbtn_delaytestdis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_delaytestdis.UseVisualStyleBackColor = true;
            // 
            // rbtn_delaytesten
            // 
            this.rbtn_delaytesten.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_delaytesten.Checked = true;
            this.rbtn_delaytesten.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_delaytesten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_delaytesten.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_delaytesten.ForeColor = System.Drawing.Color.Black;
            this.rbtn_delaytesten.Location = new System.Drawing.Point(27, 24);
            this.rbtn_delaytesten.Name = "rbtn_delaytesten";
            this.rbtn_delaytesten.Size = new System.Drawing.Size(83, 30);
            this.rbtn_delaytesten.TabIndex = 124;
            this.rbtn_delaytesten.TabStop = true;
            this.rbtn_delaytesten.Text = "开启";
            this.rbtn_delaytesten.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_delaytesten.UseVisualStyleBackColor = true;
            // 
            // groupBox32
            // 
            this.groupBox32.Controls.Add(this.rbtn_cooldis);
            this.groupBox32.Controls.Add(this.rbtn_coolen);
            this.groupBox32.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox32.Location = new System.Drawing.Point(949, 404);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Size = new System.Drawing.Size(117, 110);
            this.groupBox32.TabIndex = 144;
            this.groupBox32.TabStop = false;
            this.groupBox32.Text = "降温设置";
            // 
            // rbtn_cooldis
            // 
            this.rbtn_cooldis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_cooldis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_cooldis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_cooldis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_cooldis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_cooldis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_cooldis.Name = "rbtn_cooldis";
            this.rbtn_cooldis.Size = new System.Drawing.Size(75, 30);
            this.rbtn_cooldis.TabIndex = 126;
            this.rbtn_cooldis.Text = "关闭";
            this.rbtn_cooldis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_cooldis.UseVisualStyleBackColor = true;
            // 
            // rbtn_coolen
            // 
            this.rbtn_coolen.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_coolen.Checked = true;
            this.rbtn_coolen.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_coolen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_coolen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_coolen.ForeColor = System.Drawing.Color.Black;
            this.rbtn_coolen.Location = new System.Drawing.Point(27, 24);
            this.rbtn_coolen.Name = "rbtn_coolen";
            this.rbtn_coolen.Size = new System.Drawing.Size(75, 30);
            this.rbtn_coolen.TabIndex = 124;
            this.rbtn_coolen.TabStop = true;
            this.rbtn_coolen.Text = "开启";
            this.rbtn_coolen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_coolen.UseVisualStyleBackColor = true;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.rbtn_CycleDis);
            this.groupBox31.Controls.Add(this.rbtn_CycleEn);
            this.groupBox31.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox31.Location = new System.Drawing.Point(728, 404);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(209, 110);
            this.groupBox31.TabIndex = 143;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "上下料周期记录保存设置";
            // 
            // rbtn_CycleDis
            // 
            this.rbtn_CycleDis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_CycleDis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_CycleDis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_CycleDis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_CycleDis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_CycleDis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_CycleDis.Name = "rbtn_CycleDis";
            this.rbtn_CycleDis.Size = new System.Drawing.Size(155, 30);
            this.rbtn_CycleDis.TabIndex = 126;
            this.rbtn_CycleDis.Text = "关闭";
            this.rbtn_CycleDis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_CycleDis.UseVisualStyleBackColor = true;
            // 
            // rbtn_CycleEn
            // 
            this.rbtn_CycleEn.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_CycleEn.Checked = true;
            this.rbtn_CycleEn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_CycleEn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_CycleEn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_CycleEn.ForeColor = System.Drawing.Color.Black;
            this.rbtn_CycleEn.Location = new System.Drawing.Point(27, 24);
            this.rbtn_CycleEn.Name = "rbtn_CycleEn";
            this.rbtn_CycleEn.Size = new System.Drawing.Size(155, 30);
            this.rbtn_CycleEn.TabIndex = 124;
            this.rbtn_CycleEn.TabStop = true;
            this.rbtn_CycleEn.Text = "开启";
            this.rbtn_CycleEn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_CycleEn.UseVisualStyleBackColor = true;
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.dateTimePicker2);
            this.groupBox30.Controls.Add(this.dateTimePicker1);
            this.groupBox30.Controls.Add(this.label28);
            this.groupBox30.Controls.Add(this.label29);
            this.groupBox30.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox30.Location = new System.Drawing.Point(513, 403);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(209, 111);
            this.groupBox30.TabIndex = 142;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "点检提示";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "HH:mm:ss";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(90, 69);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.ShowUpDown = true;
            this.dateTimePicker2.Size = new System.Drawing.Size(92, 23);
            this.dateTimePicker2.TabIndex = 41;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "HH:mm:ss";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(90, 28);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.ShowUpDown = true;
            this.dateTimePicker1.Size = new System.Drawing.Size(91, 23);
            this.dateTimePicker1.TabIndex = 40;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label28.Location = new System.Drawing.Point(19, 32);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(48, 16);
            this.label28.TabIndex = 39;
            this.label28.Text = "早上:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.Location = new System.Drawing.Point(19, 73);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(48, 16);
            this.label29.TabIndex = 2;
            this.label29.Text = "晚上:";
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.nud_jig_exposure2);
            this.groupBox28.Controls.Add(this.nud_jig_contrast2);
            this.groupBox28.Controls.Add(this.nud_jig_brightness2);
            this.groupBox28.Controls.Add(this.label33);
            this.groupBox28.Controls.Add(this.nud_jig_exposure1);
            this.groupBox28.Controls.Add(this.nud_jig_contrast1);
            this.groupBox28.Controls.Add(this.nud_jig_brightness1);
            this.groupBox28.Controls.Add(this.label31);
            this.groupBox28.Controls.Add(this.nud_ws_exposure2);
            this.groupBox28.Controls.Add(this.nud_tray_exposure2);
            this.groupBox28.Controls.Add(this.nud_ws_contrast2);
            this.groupBox28.Controls.Add(this.nud_ws_brightness2);
            this.groupBox28.Controls.Add(this.nud_tray_contrast2);
            this.groupBox28.Controls.Add(this.label26);
            this.groupBox28.Controls.Add(this.nud_tray_brightness2);
            this.groupBox28.Controls.Add(this.label27);
            this.groupBox28.Controls.Add(this.nud_ws_exposure1);
            this.groupBox28.Controls.Add(this.nud_tray_exposure1);
            this.groupBox28.Controls.Add(this.nud_ws_contrast1);
            this.groupBox28.Controls.Add(this.nud_ws_brightness1);
            this.groupBox28.Controls.Add(this.nud_tray_contrast1);
            this.groupBox28.Controls.Add(this.label25);
            this.groupBox28.Controls.Add(this.label24);
            this.groupBox28.Controls.Add(this.label23);
            this.groupBox28.Controls.Add(this.label22);
            this.groupBox28.Controls.Add(this.nud_tray_brightness1);
            this.groupBox28.Controls.Add(this.label21);
            this.groupBox28.Controls.Add(this.rbtn_camcfgsetdis);
            this.groupBox28.Controls.Add(this.rbtn_camcfgseten);
            this.groupBox28.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox28.Location = new System.Drawing.Point(27, 535);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(607, 153);
            this.groupBox28.TabIndex = 141;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "相机多种参数设置";
            // 
            // nud_jig_exposure2
            // 
            this.nud_jig_exposure2.BackColor = System.Drawing.SystemColors.Window;
            this.nud_jig_exposure2.DecimalPlaces = 3;
            this.nud_jig_exposure2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_jig_exposure2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_jig_exposure2.Location = new System.Drawing.Point(453, 44);
            this.nud_jig_exposure2.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_jig_exposure2.Name = "nud_jig_exposure2";
            this.nud_jig_exposure2.Size = new System.Drawing.Size(62, 26);
            this.nud_jig_exposure2.TabIndex = 156;
            this.nud_jig_exposure2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_jig_exposure2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_jig_contrast2
            // 
            this.nud_jig_contrast2.BackColor = System.Drawing.SystemColors.Window;
            this.nud_jig_contrast2.DecimalPlaces = 3;
            this.nud_jig_contrast2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_jig_contrast2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_jig_contrast2.Location = new System.Drawing.Point(453, 108);
            this.nud_jig_contrast2.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_jig_contrast2.Name = "nud_jig_contrast2";
            this.nud_jig_contrast2.Size = new System.Drawing.Size(62, 26);
            this.nud_jig_contrast2.TabIndex = 155;
            this.nud_jig_contrast2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_jig_contrast2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_jig_brightness2
            // 
            this.nud_jig_brightness2.BackColor = System.Drawing.SystemColors.Window;
            this.nud_jig_brightness2.DecimalPlaces = 3;
            this.nud_jig_brightness2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_jig_brightness2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_jig_brightness2.Location = new System.Drawing.Point(453, 76);
            this.nud_jig_brightness2.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_jig_brightness2.Name = "nud_jig_brightness2";
            this.nud_jig_brightness2.Size = new System.Drawing.Size(62, 26);
            this.nud_jig_brightness2.TabIndex = 154;
            this.nud_jig_brightness2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_jig_brightness2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("宋体", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.Location = new System.Drawing.Point(451, 19);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(45, 10);
            this.label33.TabIndex = 153;
            this.label33.Text = "夹具拍2:";
            // 
            // nud_jig_exposure1
            // 
            this.nud_jig_exposure1.BackColor = System.Drawing.SystemColors.Window;
            this.nud_jig_exposure1.DecimalPlaces = 3;
            this.nud_jig_exposure1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_jig_exposure1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_jig_exposure1.Location = new System.Drawing.Point(236, 44);
            this.nud_jig_exposure1.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_jig_exposure1.Name = "nud_jig_exposure1";
            this.nud_jig_exposure1.Size = new System.Drawing.Size(62, 26);
            this.nud_jig_exposure1.TabIndex = 152;
            this.nud_jig_exposure1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_jig_exposure1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_jig_contrast1
            // 
            this.nud_jig_contrast1.BackColor = System.Drawing.SystemColors.Window;
            this.nud_jig_contrast1.DecimalPlaces = 3;
            this.nud_jig_contrast1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_jig_contrast1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_jig_contrast1.Location = new System.Drawing.Point(236, 107);
            this.nud_jig_contrast1.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_jig_contrast1.Name = "nud_jig_contrast1";
            this.nud_jig_contrast1.Size = new System.Drawing.Size(62, 26);
            this.nud_jig_contrast1.TabIndex = 151;
            this.nud_jig_contrast1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_jig_contrast1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_jig_brightness1
            // 
            this.nud_jig_brightness1.BackColor = System.Drawing.SystemColors.Window;
            this.nud_jig_brightness1.DecimalPlaces = 3;
            this.nud_jig_brightness1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_jig_brightness1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_jig_brightness1.Location = new System.Drawing.Point(236, 76);
            this.nud_jig_brightness1.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_jig_brightness1.Name = "nud_jig_brightness1";
            this.nud_jig_brightness1.Size = new System.Drawing.Size(62, 26);
            this.nud_jig_brightness1.TabIndex = 150;
            this.nud_jig_brightness1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_jig_brightness1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("宋体", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(241, 19);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(45, 10);
            this.label31.TabIndex = 149;
            this.label31.Text = "夹具拍1:";
            // 
            // nud_ws_exposure2
            // 
            this.nud_ws_exposure2.BackColor = System.Drawing.SystemColors.Window;
            this.nud_ws_exposure2.DecimalPlaces = 3;
            this.nud_ws_exposure2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_ws_exposure2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_ws_exposure2.Location = new System.Drawing.Point(372, 44);
            this.nud_ws_exposure2.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_ws_exposure2.Name = "nud_ws_exposure2";
            this.nud_ws_exposure2.Size = new System.Drawing.Size(62, 26);
            this.nud_ws_exposure2.TabIndex = 148;
            this.nud_ws_exposure2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_ws_exposure2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_tray_exposure2
            // 
            this.nud_tray_exposure2.BackColor = System.Drawing.SystemColors.Window;
            this.nud_tray_exposure2.DecimalPlaces = 3;
            this.nud_tray_exposure2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_tray_exposure2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_tray_exposure2.Location = new System.Drawing.Point(304, 46);
            this.nud_tray_exposure2.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_tray_exposure2.Name = "nud_tray_exposure2";
            this.nud_tray_exposure2.Size = new System.Drawing.Size(62, 26);
            this.nud_tray_exposure2.TabIndex = 147;
            this.nud_tray_exposure2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_tray_exposure2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_ws_contrast2
            // 
            this.nud_ws_contrast2.BackColor = System.Drawing.SystemColors.Window;
            this.nud_ws_contrast2.DecimalPlaces = 3;
            this.nud_ws_contrast2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_ws_contrast2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_ws_contrast2.Location = new System.Drawing.Point(372, 108);
            this.nud_ws_contrast2.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_ws_contrast2.Name = "nud_ws_contrast2";
            this.nud_ws_contrast2.Size = new System.Drawing.Size(62, 26);
            this.nud_ws_contrast2.TabIndex = 146;
            this.nud_ws_contrast2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_ws_contrast2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_ws_brightness2
            // 
            this.nud_ws_brightness2.BackColor = System.Drawing.SystemColors.Window;
            this.nud_ws_brightness2.DecimalPlaces = 3;
            this.nud_ws_brightness2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_ws_brightness2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_ws_brightness2.Location = new System.Drawing.Point(372, 76);
            this.nud_ws_brightness2.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_ws_brightness2.Name = "nud_ws_brightness2";
            this.nud_ws_brightness2.Size = new System.Drawing.Size(62, 26);
            this.nud_ws_brightness2.TabIndex = 145;
            this.nud_ws_brightness2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_ws_brightness2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_tray_contrast2
            // 
            this.nud_tray_contrast2.BackColor = System.Drawing.SystemColors.Window;
            this.nud_tray_contrast2.DecimalPlaces = 3;
            this.nud_tray_contrast2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_tray_contrast2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_tray_contrast2.Location = new System.Drawing.Point(304, 110);
            this.nud_tray_contrast2.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_tray_contrast2.Name = "nud_tray_contrast2";
            this.nud_tray_contrast2.Size = new System.Drawing.Size(62, 26);
            this.nud_tray_contrast2.TabIndex = 144;
            this.nud_tray_contrast2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_tray_contrast2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("宋体", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.Location = new System.Drawing.Point(370, 19);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(55, 10);
            this.label26.TabIndex = 143;
            this.label26.Text = "工站拍照2:";
            // 
            // nud_tray_brightness2
            // 
            this.nud_tray_brightness2.BackColor = System.Drawing.SystemColors.Window;
            this.nud_tray_brightness2.DecimalPlaces = 3;
            this.nud_tray_brightness2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_tray_brightness2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_tray_brightness2.Location = new System.Drawing.Point(304, 78);
            this.nud_tray_brightness2.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_tray_brightness2.Name = "nud_tray_brightness2";
            this.nud_tray_brightness2.Size = new System.Drawing.Size(62, 26);
            this.nud_tray_brightness2.TabIndex = 142;
            this.nud_tray_brightness2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_tray_brightness2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("宋体", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(302, 19);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(55, 10);
            this.label27.TabIndex = 141;
            this.label27.Text = "料盘拍照2:";
            // 
            // nud_ws_exposure1
            // 
            this.nud_ws_exposure1.BackColor = System.Drawing.SystemColors.Window;
            this.nud_ws_exposure1.DecimalPlaces = 3;
            this.nud_ws_exposure1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_ws_exposure1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_ws_exposure1.Location = new System.Drawing.Point(173, 46);
            this.nud_ws_exposure1.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_ws_exposure1.Name = "nud_ws_exposure1";
            this.nud_ws_exposure1.Size = new System.Drawing.Size(62, 26);
            this.nud_ws_exposure1.TabIndex = 140;
            this.nud_ws_exposure1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_ws_exposure1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_tray_exposure1
            // 
            this.nud_tray_exposure1.BackColor = System.Drawing.SystemColors.Window;
            this.nud_tray_exposure1.DecimalPlaces = 3;
            this.nud_tray_exposure1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_tray_exposure1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_tray_exposure1.Location = new System.Drawing.Point(105, 46);
            this.nud_tray_exposure1.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_tray_exposure1.Name = "nud_tray_exposure1";
            this.nud_tray_exposure1.Size = new System.Drawing.Size(62, 26);
            this.nud_tray_exposure1.TabIndex = 139;
            this.nud_tray_exposure1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_tray_exposure1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_ws_contrast1
            // 
            this.nud_ws_contrast1.BackColor = System.Drawing.SystemColors.Window;
            this.nud_ws_contrast1.DecimalPlaces = 3;
            this.nud_ws_contrast1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_ws_contrast1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_ws_contrast1.Location = new System.Drawing.Point(173, 109);
            this.nud_ws_contrast1.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_ws_contrast1.Name = "nud_ws_contrast1";
            this.nud_ws_contrast1.Size = new System.Drawing.Size(62, 26);
            this.nud_ws_contrast1.TabIndex = 138;
            this.nud_ws_contrast1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_ws_contrast1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_ws_brightness1
            // 
            this.nud_ws_brightness1.BackColor = System.Drawing.SystemColors.Window;
            this.nud_ws_brightness1.DecimalPlaces = 3;
            this.nud_ws_brightness1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_ws_brightness1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_ws_brightness1.Location = new System.Drawing.Point(173, 78);
            this.nud_ws_brightness1.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_ws_brightness1.Name = "nud_ws_brightness1";
            this.nud_ws_brightness1.Size = new System.Drawing.Size(62, 26);
            this.nud_ws_brightness1.TabIndex = 137;
            this.nud_ws_brightness1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_ws_brightness1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_tray_contrast1
            // 
            this.nud_tray_contrast1.BackColor = System.Drawing.SystemColors.Window;
            this.nud_tray_contrast1.DecimalPlaces = 3;
            this.nud_tray_contrast1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_tray_contrast1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_tray_contrast1.Location = new System.Drawing.Point(105, 110);
            this.nud_tray_contrast1.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_tray_contrast1.Name = "nud_tray_contrast1";
            this.nud_tray_contrast1.Size = new System.Drawing.Size(62, 26);
            this.nud_tray_contrast1.TabIndex = 136;
            this.nud_tray_contrast1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_tray_contrast1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(6, 114);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(104, 16);
            this.label25.TabIndex = 135;
            this.label25.Text = "对比度(0-1):";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(6, 80);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(88, 16);
            this.label24.TabIndex = 134;
            this.label24.Text = "亮度(0-1):";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(6, 46);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(80, 16);
            this.label23.TabIndex = 133;
            this.label23.Text = "曝光(ms):";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("宋体", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(170, 19);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(45, 10);
            this.label22.TabIndex = 132;
            this.label22.Text = "工站拍1:";
            // 
            // nud_tray_brightness1
            // 
            this.nud_tray_brightness1.BackColor = System.Drawing.SystemColors.Window;
            this.nud_tray_brightness1.DecimalPlaces = 3;
            this.nud_tray_brightness1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_tray_brightness1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_tray_brightness1.Location = new System.Drawing.Point(105, 78);
            this.nud_tray_brightness1.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_tray_brightness1.Name = "nud_tray_brightness1";
            this.nud_tray_brightness1.Size = new System.Drawing.Size(62, 26);
            this.nud_tray_brightness1.TabIndex = 131;
            this.nud_tray_brightness1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_tray_brightness1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("宋体", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(103, 19);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(55, 10);
            this.label21.TabIndex = 130;
            this.label21.Text = "料盘拍照1:";
            // 
            // rbtn_camcfgsetdis
            // 
            this.rbtn_camcfgsetdis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_camcfgsetdis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_camcfgsetdis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_camcfgsetdis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_camcfgsetdis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_camcfgsetdis.Location = new System.Drawing.Point(530, 104);
            this.rbtn_camcfgsetdis.Name = "rbtn_camcfgsetdis";
            this.rbtn_camcfgsetdis.Size = new System.Drawing.Size(71, 30);
            this.rbtn_camcfgsetdis.TabIndex = 126;
            this.rbtn_camcfgsetdis.Text = "关闭";
            this.rbtn_camcfgsetdis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_camcfgsetdis.UseVisualStyleBackColor = true;
            // 
            // rbtn_camcfgseten
            // 
            this.rbtn_camcfgseten.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_camcfgseten.Checked = true;
            this.rbtn_camcfgseten.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_camcfgseten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_camcfgseten.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_camcfgseten.ForeColor = System.Drawing.Color.Black;
            this.rbtn_camcfgseten.Location = new System.Drawing.Point(530, 44);
            this.rbtn_camcfgseten.Name = "rbtn_camcfgseten";
            this.rbtn_camcfgseten.Size = new System.Drawing.Size(71, 30);
            this.rbtn_camcfgseten.TabIndex = 124;
            this.rbtn_camcfgseten.TabStop = true;
            this.rbtn_camcfgseten.Text = "开启";
            this.rbtn_camcfgseten.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_camcfgseten.UseVisualStyleBackColor = true;
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.nud_cleaninterval);
            this.groupBox25.Controls.Add(this.label20);
            this.groupBox25.Controls.Add(this.rbtn_cleandis);
            this.groupBox25.Controls.Add(this.rbtn_cleanen);
            this.groupBox25.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox25.Location = new System.Drawing.Point(728, 275);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(209, 110);
            this.groupBox25.TabIndex = 140;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "夹具清洗设置";
            // 
            // nud_cleaninterval
            // 
            this.nud_cleaninterval.BackColor = System.Drawing.SystemColors.Window;
            this.nud_cleaninterval.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_cleaninterval.Location = new System.Drawing.Point(108, 62);
            this.nud_cleaninterval.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_cleaninterval.Name = "nud_cleaninterval";
            this.nud_cleaninterval.Size = new System.Drawing.Size(82, 32);
            this.nud_cleaninterval.TabIndex = 131;
            this.nud_cleaninterval.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_cleaninterval.Value = new decimal(new int[] {
            120,
            0,
            0,
            0});
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(110, 30);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(80, 16);
            this.label20.TabIndex = 130;
            this.label20.Text = "清洗间隔:";
            // 
            // rbtn_cleandis
            // 
            this.rbtn_cleandis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_cleandis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_cleandis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_cleandis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_cleandis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_cleandis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_cleandis.Name = "rbtn_cleandis";
            this.rbtn_cleandis.Size = new System.Drawing.Size(71, 30);
            this.rbtn_cleandis.TabIndex = 126;
            this.rbtn_cleandis.Text = "关闭";
            this.rbtn_cleandis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_cleandis.UseVisualStyleBackColor = true;
            // 
            // rbtn_cleanen
            // 
            this.rbtn_cleanen.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_cleanen.Checked = true;
            this.rbtn_cleanen.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_cleanen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_cleanen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_cleanen.ForeColor = System.Drawing.Color.Black;
            this.rbtn_cleanen.Location = new System.Drawing.Point(27, 24);
            this.rbtn_cleanen.Name = "rbtn_cleanen";
            this.rbtn_cleanen.Size = new System.Drawing.Size(71, 30);
            this.rbtn_cleanen.TabIndex = 124;
            this.rbtn_cleanen.TabStop = true;
            this.rbtn_cleanen.Text = "开启";
            this.rbtn_cleanen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_cleanen.UseVisualStyleBackColor = true;
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.rbtn_nonparalleldis);
            this.groupBox27.Controls.Add(this.rbtn_nonparallelen);
            this.groupBox27.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox27.Location = new System.Drawing.Point(728, 149);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(209, 110);
            this.groupBox27.TabIndex = 139;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "夹具双工位非平行设置";
            // 
            // rbtn_nonparalleldis
            // 
            this.rbtn_nonparalleldis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_nonparalleldis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_nonparalleldis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_nonparalleldis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_nonparalleldis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_nonparalleldis.Location = new System.Drawing.Point(21, 64);
            this.rbtn_nonparalleldis.Name = "rbtn_nonparalleldis";
            this.rbtn_nonparalleldis.Size = new System.Drawing.Size(155, 30);
            this.rbtn_nonparalleldis.TabIndex = 126;
            this.rbtn_nonparalleldis.Text = "关闭";
            this.rbtn_nonparalleldis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_nonparalleldis.UseVisualStyleBackColor = true;
            // 
            // rbtn_nonparallelen
            // 
            this.rbtn_nonparallelen.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_nonparallelen.Checked = true;
            this.rbtn_nonparallelen.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_nonparallelen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_nonparallelen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_nonparallelen.ForeColor = System.Drawing.Color.Black;
            this.rbtn_nonparallelen.Location = new System.Drawing.Point(21, 25);
            this.rbtn_nonparallelen.Name = "rbtn_nonparallelen";
            this.rbtn_nonparallelen.Size = new System.Drawing.Size(155, 30);
            this.rbtn_nonparallelen.TabIndex = 124;
            this.rbtn_nonparallelen.TabStop = true;
            this.rbtn_nonparallelen.Text = "开启";
            this.rbtn_nonparallelen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_nonparallelen.UseVisualStyleBackColor = true;
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.rbtn_backerrcontinuedis);
            this.groupBox26.Controls.Add(this.rbtn_backerrcontinueen);
            this.groupBox26.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox26.Location = new System.Drawing.Point(270, 404);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(209, 110);
            this.groupBox26.TabIndex = 138;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "回检失败继续运行设置";
            // 
            // rbtn_backerrcontinuedis
            // 
            this.rbtn_backerrcontinuedis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_backerrcontinuedis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_backerrcontinuedis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_backerrcontinuedis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_backerrcontinuedis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_backerrcontinuedis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_backerrcontinuedis.Name = "rbtn_backerrcontinuedis";
            this.rbtn_backerrcontinuedis.Size = new System.Drawing.Size(155, 30);
            this.rbtn_backerrcontinuedis.TabIndex = 126;
            this.rbtn_backerrcontinuedis.Text = "关闭";
            this.rbtn_backerrcontinuedis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_backerrcontinuedis.UseVisualStyleBackColor = true;
            // 
            // rbtn_backerrcontinueen
            // 
            this.rbtn_backerrcontinueen.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_backerrcontinueen.Checked = true;
            this.rbtn_backerrcontinueen.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_backerrcontinueen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_backerrcontinueen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_backerrcontinueen.ForeColor = System.Drawing.Color.Black;
            this.rbtn_backerrcontinueen.Location = new System.Drawing.Point(27, 24);
            this.rbtn_backerrcontinueen.Name = "rbtn_backerrcontinueen";
            this.rbtn_backerrcontinueen.Size = new System.Drawing.Size(155, 30);
            this.rbtn_backerrcontinueen.TabIndex = 124;
            this.rbtn_backerrcontinueen.TabStop = true;
            this.rbtn_backerrcontinueen.Text = "开启";
            this.rbtn_backerrcontinueen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_backerrcontinueen.UseVisualStyleBackColor = true;
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.rbtn_RY1dis);
            this.groupBox24.Controls.Add(this.rbtn_RY1en);
            this.groupBox24.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox24.Location = new System.Drawing.Point(27, 404);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(209, 110);
            this.groupBox24.TabIndex = 136;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "右光箱增距镜Y1开启设置";
            // 
            // rbtn_RY1dis
            // 
            this.rbtn_RY1dis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_RY1dis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_RY1dis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_RY1dis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_RY1dis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_RY1dis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_RY1dis.Name = "rbtn_RY1dis";
            this.rbtn_RY1dis.Size = new System.Drawing.Size(155, 30);
            this.rbtn_RY1dis.TabIndex = 126;
            this.rbtn_RY1dis.Text = "关闭";
            this.rbtn_RY1dis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_RY1dis.UseVisualStyleBackColor = true;
            // 
            // rbtn_RY1en
            // 
            this.rbtn_RY1en.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_RY1en.Checked = true;
            this.rbtn_RY1en.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_RY1en.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_RY1en.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_RY1en.ForeColor = System.Drawing.Color.Black;
            this.rbtn_RY1en.Location = new System.Drawing.Point(27, 24);
            this.rbtn_RY1en.Name = "rbtn_RY1en";
            this.rbtn_RY1en.Size = new System.Drawing.Size(155, 30);
            this.rbtn_RY1en.TabIndex = 124;
            this.rbtn_RY1en.TabStop = true;
            this.rbtn_RY1en.Text = "开启";
            this.rbtn_RY1en.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_RY1en.UseVisualStyleBackColor = true;
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.rbtn_xt1firstdis);
            this.groupBox23.Controls.Add(this.rbtn_xt1firsten);
            this.groupBox23.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox23.Location = new System.Drawing.Point(513, 149);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(209, 108);
            this.groupBox23.TabIndex = 135;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "吸头1先运动设置";
            // 
            // rbtn_xt1firstdis
            // 
            this.rbtn_xt1firstdis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_xt1firstdis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_xt1firstdis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_xt1firstdis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_xt1firstdis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_xt1firstdis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_xt1firstdis.Name = "rbtn_xt1firstdis";
            this.rbtn_xt1firstdis.Size = new System.Drawing.Size(155, 30);
            this.rbtn_xt1firstdis.TabIndex = 126;
            this.rbtn_xt1firstdis.Text = "关闭";
            this.rbtn_xt1firstdis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_xt1firstdis.UseVisualStyleBackColor = true;
            // 
            // rbtn_xt1firsten
            // 
            this.rbtn_xt1firsten.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_xt1firsten.Checked = true;
            this.rbtn_xt1firsten.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_xt1firsten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_xt1firsten.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_xt1firsten.ForeColor = System.Drawing.Color.Black;
            this.rbtn_xt1firsten.Location = new System.Drawing.Point(27, 25);
            this.rbtn_xt1firsten.Name = "rbtn_xt1firsten";
            this.rbtn_xt1firsten.Size = new System.Drawing.Size(155, 30);
            this.rbtn_xt1firsten.TabIndex = 124;
            this.rbtn_xt1firsten.TabStop = true;
            this.rbtn_xt1firsten.Text = "开启";
            this.rbtn_xt1firsten.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_xt1firsten.UseVisualStyleBackColor = true;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.rbtn_traybardis);
            this.groupBox22.Controls.Add(this.rbtn_traybaren);
            this.groupBox22.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox22.Location = new System.Drawing.Point(513, 275);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(209, 108);
            this.groupBox22.TabIndex = 134;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "料盘二维码拍照设置";
            // 
            // rbtn_traybardis
            // 
            this.rbtn_traybardis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_traybardis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_traybardis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_traybardis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_traybardis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_traybardis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_traybardis.Name = "rbtn_traybardis";
            this.rbtn_traybardis.Size = new System.Drawing.Size(155, 30);
            this.rbtn_traybardis.TabIndex = 126;
            this.rbtn_traybardis.Text = "关闭";
            this.rbtn_traybardis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_traybardis.UseVisualStyleBackColor = true;
            // 
            // rbtn_traybaren
            // 
            this.rbtn_traybaren.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_traybaren.Checked = true;
            this.rbtn_traybaren.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_traybaren.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_traybaren.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_traybaren.ForeColor = System.Drawing.Color.Black;
            this.rbtn_traybaren.Location = new System.Drawing.Point(27, 25);
            this.rbtn_traybaren.Name = "rbtn_traybaren";
            this.rbtn_traybaren.Size = new System.Drawing.Size(155, 30);
            this.rbtn_traybaren.TabIndex = 124;
            this.rbtn_traybaren.TabStop = true;
            this.rbtn_traybaren.Text = "开启";
            this.rbtn_traybaren.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_traybaren.UseVisualStyleBackColor = true;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.rbtn_halldis);
            this.groupBox21.Controls.Add(this.rbtn_hallen);
            this.groupBox21.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox21.Location = new System.Drawing.Point(27, 275);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(209, 108);
            this.groupBox21.TabIndex = 133;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "霍尔测试";
            // 
            // rbtn_halldis
            // 
            this.rbtn_halldis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_halldis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_halldis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_halldis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_halldis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_halldis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_halldis.Name = "rbtn_halldis";
            this.rbtn_halldis.Size = new System.Drawing.Size(155, 30);
            this.rbtn_halldis.TabIndex = 126;
            this.rbtn_halldis.Text = "关闭";
            this.rbtn_halldis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_halldis.UseVisualStyleBackColor = true;
            // 
            // rbtn_hallen
            // 
            this.rbtn_hallen.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_hallen.Checked = true;
            this.rbtn_hallen.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_hallen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_hallen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_hallen.ForeColor = System.Drawing.Color.Black;
            this.rbtn_hallen.Location = new System.Drawing.Point(27, 25);
            this.rbtn_hallen.Name = "rbtn_hallen";
            this.rbtn_hallen.Size = new System.Drawing.Size(155, 30);
            this.rbtn_hallen.TabIndex = 124;
            this.rbtn_hallen.TabStop = true;
            this.rbtn_hallen.Text = "开启";
            this.rbtn_hallen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_hallen.UseVisualStyleBackColor = true;
            // 
            // btn_saveparm2
            // 
            this.btn_saveparm2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_saveparm2.Location = new System.Drawing.Point(885, 731);
            this.btn_saveparm2.Name = "btn_saveparm2";
            this.btn_saveparm2.Size = new System.Drawing.Size(134, 71);
            this.btn_saveparm2.TabIndex = 130;
            this.btn_saveparm2.Text = "保存";
            this.btn_saveparm2.UseVisualStyleBackColor = false;
            this.btn_saveparm2.Click += new System.EventHandler(this.btn_ptset_save_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbtn_CloseVsTray);
            this.groupBox2.Controls.Add(this.rbtn_OpenVsTray);
            this.groupBox2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(513, 21);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(209, 110);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "视觉检测料盘设置";
            // 
            // rbtn_CloseVsTray
            // 
            this.rbtn_CloseVsTray.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_CloseVsTray.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_CloseVsTray.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_CloseVsTray.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_CloseVsTray.ForeColor = System.Drawing.Color.Black;
            this.rbtn_CloseVsTray.Location = new System.Drawing.Point(27, 64);
            this.rbtn_CloseVsTray.Name = "rbtn_CloseVsTray";
            this.rbtn_CloseVsTray.Size = new System.Drawing.Size(155, 30);
            this.rbtn_CloseVsTray.TabIndex = 126;
            this.rbtn_CloseVsTray.Text = "关闭";
            this.rbtn_CloseVsTray.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_CloseVsTray.UseVisualStyleBackColor = true;
            // 
            // rbtn_OpenVsTray
            // 
            this.rbtn_OpenVsTray.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_OpenVsTray.Checked = true;
            this.rbtn_OpenVsTray.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_OpenVsTray.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_OpenVsTray.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_OpenVsTray.ForeColor = System.Drawing.Color.Black;
            this.rbtn_OpenVsTray.Location = new System.Drawing.Point(27, 25);
            this.rbtn_OpenVsTray.Name = "rbtn_OpenVsTray";
            this.rbtn_OpenVsTray.Size = new System.Drawing.Size(155, 30);
            this.rbtn_OpenVsTray.TabIndex = 124;
            this.rbtn_OpenVsTray.TabStop = true;
            this.rbtn_OpenVsTray.Text = "开启";
            this.rbtn_OpenVsTray.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_OpenVsTray.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.rbtn_CloseWsPickAgain);
            this.groupBox12.Controls.Add(this.rbtn_OpenWsPickAgain);
            this.groupBox12.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox12.Location = new System.Drawing.Point(270, 275);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(209, 108);
            this.groupBox12.TabIndex = 36;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "工站二次取料开启设置";
            // 
            // rbtn_CloseWsPickAgain
            // 
            this.rbtn_CloseWsPickAgain.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_CloseWsPickAgain.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_CloseWsPickAgain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_CloseWsPickAgain.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_CloseWsPickAgain.ForeColor = System.Drawing.Color.Black;
            this.rbtn_CloseWsPickAgain.Location = new System.Drawing.Point(27, 64);
            this.rbtn_CloseWsPickAgain.Name = "rbtn_CloseWsPickAgain";
            this.rbtn_CloseWsPickAgain.Size = new System.Drawing.Size(155, 30);
            this.rbtn_CloseWsPickAgain.TabIndex = 126;
            this.rbtn_CloseWsPickAgain.Text = "关闭";
            this.rbtn_CloseWsPickAgain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_CloseWsPickAgain.UseVisualStyleBackColor = true;
            // 
            // rbtn_OpenWsPickAgain
            // 
            this.rbtn_OpenWsPickAgain.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_OpenWsPickAgain.Checked = true;
            this.rbtn_OpenWsPickAgain.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_OpenWsPickAgain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_OpenWsPickAgain.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_OpenWsPickAgain.ForeColor = System.Drawing.Color.Black;
            this.rbtn_OpenWsPickAgain.Location = new System.Drawing.Point(27, 25);
            this.rbtn_OpenWsPickAgain.Name = "rbtn_OpenWsPickAgain";
            this.rbtn_OpenWsPickAgain.Size = new System.Drawing.Size(155, 30);
            this.rbtn_OpenWsPickAgain.TabIndex = 124;
            this.rbtn_OpenWsPickAgain.TabStop = true;
            this.rbtn_OpenWsPickAgain.Text = "开启";
            this.rbtn_OpenWsPickAgain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_OpenWsPickAgain.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.nud_offset_degree);
            this.groupBox17.Controls.Add(this.label17);
            this.groupBox17.Controls.Add(this.rbtn_close_degree);
            this.groupBox17.Controls.Add(this.rbtn_open_degree);
            this.groupBox17.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox17.Location = new System.Drawing.Point(728, 21);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(209, 108);
            this.groupBox17.TabIndex = 129;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "取放料角度设置";
            // 
            // nud_offset_degree
            // 
            this.nud_offset_degree.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_offset_degree.Location = new System.Drawing.Point(113, 62);
            this.nud_offset_degree.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nud_offset_degree.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nud_offset_degree.Name = "nud_offset_degree";
            this.nud_offset_degree.Size = new System.Drawing.Size(82, 32);
            this.nud_offset_degree.TabIndex = 130;
            this.nud_offset_degree.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_offset_degree.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(113, 31);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 16);
            this.label17.TabIndex = 129;
            this.label17.Text = "角度:";
            // 
            // rbtn_close_degree
            // 
            this.rbtn_close_degree.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_close_degree.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_close_degree.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_close_degree.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_close_degree.ForeColor = System.Drawing.Color.Black;
            this.rbtn_close_degree.Location = new System.Drawing.Point(21, 64);
            this.rbtn_close_degree.Name = "rbtn_close_degree";
            this.rbtn_close_degree.Size = new System.Drawing.Size(77, 30);
            this.rbtn_close_degree.TabIndex = 126;
            this.rbtn_close_degree.Text = "关闭";
            this.rbtn_close_degree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_close_degree.UseVisualStyleBackColor = true;
            // 
            // rbtn_open_degree
            // 
            this.rbtn_open_degree.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_open_degree.Checked = true;
            this.rbtn_open_degree.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_open_degree.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_open_degree.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_open_degree.ForeColor = System.Drawing.Color.Black;
            this.rbtn_open_degree.Location = new System.Drawing.Point(21, 25);
            this.rbtn_open_degree.Name = "rbtn_open_degree";
            this.rbtn_open_degree.Size = new System.Drawing.Size(77, 30);
            this.rbtn_open_degree.TabIndex = 124;
            this.rbtn_open_degree.TabStop = true;
            this.rbtn_open_degree.Text = "开启";
            this.rbtn_open_degree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_open_degree.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.rbtn_CloseWsVsAddCheck);
            this.groupBox9.Controls.Add(this.rbtn_OpenWsVsAddCheck);
            this.groupBox9.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox9.Location = new System.Drawing.Point(27, 149);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(209, 108);
            this.groupBox9.TabIndex = 33;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "工站视觉模板增加有无检测";
            // 
            // rbtn_CloseWsVsAddCheck
            // 
            this.rbtn_CloseWsVsAddCheck.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_CloseWsVsAddCheck.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_CloseWsVsAddCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_CloseWsVsAddCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_CloseWsVsAddCheck.ForeColor = System.Drawing.Color.Black;
            this.rbtn_CloseWsVsAddCheck.Location = new System.Drawing.Point(27, 64);
            this.rbtn_CloseWsVsAddCheck.Name = "rbtn_CloseWsVsAddCheck";
            this.rbtn_CloseWsVsAddCheck.Size = new System.Drawing.Size(155, 30);
            this.rbtn_CloseWsVsAddCheck.TabIndex = 126;
            this.rbtn_CloseWsVsAddCheck.Text = "关闭";
            this.rbtn_CloseWsVsAddCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_CloseWsVsAddCheck.UseVisualStyleBackColor = true;
            // 
            // rbtn_OpenWsVsAddCheck
            // 
            this.rbtn_OpenWsVsAddCheck.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_OpenWsVsAddCheck.Checked = true;
            this.rbtn_OpenWsVsAddCheck.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_OpenWsVsAddCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_OpenWsVsAddCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_OpenWsVsAddCheck.ForeColor = System.Drawing.Color.Black;
            this.rbtn_OpenWsVsAddCheck.Location = new System.Drawing.Point(27, 25);
            this.rbtn_OpenWsVsAddCheck.Name = "rbtn_OpenWsVsAddCheck";
            this.rbtn_OpenWsVsAddCheck.Size = new System.Drawing.Size(155, 30);
            this.rbtn_OpenWsVsAddCheck.TabIndex = 124;
            this.rbtn_OpenWsVsAddCheck.TabStop = true;
            this.rbtn_OpenWsVsAddCheck.Text = "开启";
            this.rbtn_OpenWsVsAddCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_OpenWsVsAddCheck.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.rbtn_lbdis);
            this.groupBox13.Controls.Add(this.rbtn_lben);
            this.groupBox13.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox13.Location = new System.Drawing.Point(270, 149);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(209, 108);
            this.groupBox13.TabIndex = 38;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "左右光箱开启设置";
            // 
            // rbtn_lbdis
            // 
            this.rbtn_lbdis.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_lbdis.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_lbdis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_lbdis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_lbdis.ForeColor = System.Drawing.Color.Black;
            this.rbtn_lbdis.Location = new System.Drawing.Point(27, 64);
            this.rbtn_lbdis.Name = "rbtn_lbdis";
            this.rbtn_lbdis.Size = new System.Drawing.Size(155, 30);
            this.rbtn_lbdis.TabIndex = 126;
            this.rbtn_lbdis.Text = "关闭光箱";
            this.rbtn_lbdis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_lbdis.UseVisualStyleBackColor = true;
            // 
            // rbtn_lben
            // 
            this.rbtn_lben.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_lben.Checked = true;
            this.rbtn_lben.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_lben.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_lben.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_lben.ForeColor = System.Drawing.Color.Black;
            this.rbtn_lben.Location = new System.Drawing.Point(27, 25);
            this.rbtn_lben.Name = "rbtn_lben";
            this.rbtn_lben.Size = new System.Drawing.Size(155, 30);
            this.rbtn_lben.TabIndex = 124;
            this.rbtn_lben.TabStop = true;
            this.rbtn_lben.Text = "开启光箱";
            this.rbtn_lben.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_lben.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox53);
            this.tabPage3.Controls.Add(this.groupBox52);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.groupBox49);
            this.tabPage3.Location = new System.Drawing.Point(4, 44);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1072, 726);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "参数3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox52
            // 
            this.groupBox52.Controls.Add(this.label46);
            this.groupBox52.Controls.Add(this.label45);
            this.groupBox52.Controls.Add(this.tb_eqp_pos);
            this.groupBox52.Controls.Add(this.tb_eqp_sn);
            this.groupBox52.Location = new System.Drawing.Point(334, 22);
            this.groupBox52.Name = "groupBox52";
            this.groupBox52.Size = new System.Drawing.Size(474, 254);
            this.groupBox52.TabIndex = 1;
            this.groupBox52.TabStop = false;
            this.groupBox52.Text = "设备信息";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(51, 128);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(373, 22);
            this.label46.TabIndex = 3;
            this.label46.Text = "所在位置（如新基地4号楼标杆车间）";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(51, 39);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(142, 22);
            this.label45.TabIndex = 2;
            this.label45.Text = "设备铭牌编号";
            // 
            // tb_eqp_pos
            // 
            this.tb_eqp_pos.Location = new System.Drawing.Point(55, 167);
            this.tb_eqp_pos.Name = "tb_eqp_pos";
            this.tb_eqp_pos.Size = new System.Drawing.Size(329, 32);
            this.tb_eqp_pos.TabIndex = 1;
            this.tb_eqp_pos.Text = "t";
            // 
            // tb_eqp_sn
            // 
            this.tb_eqp_sn.Location = new System.Drawing.Point(55, 80);
            this.tb_eqp_sn.Name = "tb_eqp_sn";
            this.tb_eqp_sn.Size = new System.Drawing.Size(329, 32);
            this.tb_eqp_sn.TabIndex = 0;
            this.tb_eqp_sn.Text = "123456";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(873, 419);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(134, 71);
            this.button1.TabIndex = 131;
            this.button1.Text = "保存";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btn_ptset_save_Click);
            // 
            // groupBox49
            // 
            this.groupBox49.Controls.Add(this.tabControl2);
            this.groupBox49.Location = new System.Drawing.Point(23, 22);
            this.groupBox49.Name = "groupBox49";
            this.groupBox49.Size = new System.Drawing.Size(288, 254);
            this.groupBox49.TabIndex = 0;
            this.groupBox49.TabStop = false;
            this.groupBox49.Text = "NPI专用吸头启用";
            this.groupBox49.Visible = false;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Location = new System.Drawing.Point(6, 49);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(264, 189);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox50);
            this.tabPage4.Location = new System.Drawing.Point(4, 31);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(256, 154);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "上下料1";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox50
            // 
            this.groupBox50.Controls.Add(this.rbtUpDn1OneXtOff);
            this.groupBox50.Controls.Add(this.rbtUpDn1OneXtOn);
            this.groupBox50.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox50.Location = new System.Drawing.Point(20, 15);
            this.groupBox50.Name = "groupBox50";
            this.groupBox50.Size = new System.Drawing.Size(183, 110);
            this.groupBox50.TabIndex = 154;
            this.groupBox50.TabStop = false;
            this.groupBox50.Text = "只用一个吸头";
            // 
            // rbtUpDn1OneXtOff
            // 
            this.rbtUpDn1OneXtOff.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtUpDn1OneXtOff.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtUpDn1OneXtOff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtUpDn1OneXtOff.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtUpDn1OneXtOff.ForeColor = System.Drawing.Color.Black;
            this.rbtUpDn1OneXtOff.Location = new System.Drawing.Point(25, 74);
            this.rbtUpDn1OneXtOff.Name = "rbtUpDn1OneXtOff";
            this.rbtUpDn1OneXtOff.Size = new System.Drawing.Size(87, 30);
            this.rbtUpDn1OneXtOff.TabIndex = 126;
            this.rbtUpDn1OneXtOff.Text = "关闭";
            this.rbtUpDn1OneXtOff.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtUpDn1OneXtOff.UseVisualStyleBackColor = true;
            // 
            // rbtUpDn1OneXtOn
            // 
            this.rbtUpDn1OneXtOn.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtUpDn1OneXtOn.Checked = true;
            this.rbtUpDn1OneXtOn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtUpDn1OneXtOn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtUpDn1OneXtOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtUpDn1OneXtOn.ForeColor = System.Drawing.Color.Black;
            this.rbtUpDn1OneXtOn.Location = new System.Drawing.Point(25, 31);
            this.rbtUpDn1OneXtOn.Name = "rbtUpDn1OneXtOn";
            this.rbtUpDn1OneXtOn.Size = new System.Drawing.Size(87, 30);
            this.rbtUpDn1OneXtOn.TabIndex = 124;
            this.rbtUpDn1OneXtOn.TabStop = true;
            this.rbtUpDn1OneXtOn.Text = "开启";
            this.rbtUpDn1OneXtOn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtUpDn1OneXtOn.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox51);
            this.tabPage5.Location = new System.Drawing.Point(4, 31);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(256, 154);
            this.tabPage5.TabIndex = 1;
            this.tabPage5.Text = "上下料2";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox51
            // 
            this.groupBox51.Controls.Add(this.rbtUpDn2OneXtOff);
            this.groupBox51.Controls.Add(this.rbtUpDn2OneXtOn);
            this.groupBox51.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox51.Location = new System.Drawing.Point(16, 17);
            this.groupBox51.Name = "groupBox51";
            this.groupBox51.Size = new System.Drawing.Size(195, 131);
            this.groupBox51.TabIndex = 155;
            this.groupBox51.TabStop = false;
            this.groupBox51.Text = "只用一个吸头";
            // 
            // rbtUpDn2OneXtOff
            // 
            this.rbtUpDn2OneXtOff.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtUpDn2OneXtOff.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtUpDn2OneXtOff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtUpDn2OneXtOff.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtUpDn2OneXtOff.ForeColor = System.Drawing.Color.Black;
            this.rbtUpDn2OneXtOff.Location = new System.Drawing.Point(25, 74);
            this.rbtUpDn2OneXtOff.Name = "rbtUpDn2OneXtOff";
            this.rbtUpDn2OneXtOff.Size = new System.Drawing.Size(87, 30);
            this.rbtUpDn2OneXtOff.TabIndex = 126;
            this.rbtUpDn2OneXtOff.Text = "关闭";
            this.rbtUpDn2OneXtOff.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtUpDn2OneXtOff.UseVisualStyleBackColor = true;
            // 
            // rbtUpDn2OneXtOn
            // 
            this.rbtUpDn2OneXtOn.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtUpDn2OneXtOn.Checked = true;
            this.rbtUpDn2OneXtOn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtUpDn2OneXtOn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtUpDn2OneXtOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtUpDn2OneXtOn.ForeColor = System.Drawing.Color.Black;
            this.rbtUpDn2OneXtOn.Location = new System.Drawing.Point(25, 31);
            this.rbtUpDn2OneXtOn.Name = "rbtUpDn2OneXtOn";
            this.rbtUpDn2OneXtOn.Size = new System.Drawing.Size(87, 30);
            this.rbtUpDn2OneXtOn.TabIndex = 124;
            this.rbtUpDn2OneXtOn.TabStop = true;
            this.rbtUpDn2OneXtOn.Text = "开启";
            this.rbtUpDn2OneXtOn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtUpDn2OneXtOn.UseVisualStyleBackColor = true;
            // 
            // tp_calc
            // 
            this.tp_calc.Controls.Add(this.tableLayoutPanel4);
            this.tp_calc.Location = new System.Drawing.Point(204, 4);
            this.tp_calc.Name = "tp_calc";
            this.tp_calc.Size = new System.Drawing.Size(1080, 974);
            this.tp_calc.TabIndex = 5;
            this.tp_calc.Text = "系统校准";
            this.tp_calc.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.ctb_cali, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 3;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 64.61039F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35.38961F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1080, 974);
            this.tableLayoutPanel4.TabIndex = 2;
            // 
            // ctb_cali
            // 
            this.ctb_cali.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.ctb_cali.BackColor = System.Drawing.SystemColors.Control;
            this.ctb_cali.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ctb_cali.Controls.Add(this.tb_upcam1_npoint);
            this.ctb_cali.Controls.Add(this.tb_dwcam1_to_upcam1);
            this.ctb_cali.Controls.Add(this.tb_dwcam2_to_upcam2);
            this.ctb_cali.Controls.Add(this.Tb_ComputeCenter);
            this.ctb_cali.Controls.Add(this.tb_task_npoint);
            this.ctb_cali.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctb_cali.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.ctb_cali.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ctb_cali.HeaderBackColor = System.Drawing.SystemColors.ButtonFace;
            this.ctb_cali.HeadSelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(144)))), ((int)(((byte)(217)))));
            this.ctb_cali.HeadSelectedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.ctb_cali.ItemSize = new System.Drawing.Size(44, 210);
            this.ctb_cali.Location = new System.Drawing.Point(3, 627);
            this.ctb_cali.Multiline = true;
            this.ctb_cali.Name = "ctb_cali";
            this.ctb_cali.SelectedIndex = 0;
            this.ctb_cali.Size = new System.Drawing.Size(1074, 335);
            this.ctb_cali.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.ctb_cali.TabIndex = 130;
            // 
            // tb_upcam1_npoint
            // 
            this.tb_upcam1_npoint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.tb_upcam1_npoint.Controls.Add(this.npointCail1);
            this.tb_upcam1_npoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_upcam1_npoint.Location = new System.Drawing.Point(214, 4);
            this.tb_upcam1_npoint.Name = "tb_upcam1_npoint";
            this.tb_upcam1_npoint.Padding = new System.Windows.Forms.Padding(3);
            this.tb_upcam1_npoint.Size = new System.Drawing.Size(856, 327);
            this.tb_upcam1_npoint.TabIndex = 0;
            this.tb_upcam1_npoint.Text = "上相机1标定";
            // 
            // npointCail1
            // 
            this.npointCail1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.npointCail1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.npointCail1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npointCail1.Location = new System.Drawing.Point(3, 3);
            this.npointCail1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.npointCail1.Name = "npointCail1";
            this.npointCail1.Size = new System.Drawing.Size(850, 321);
            this.npointCail1.TabIndex = 0;
            // 
            // tb_dwcam1_to_upcam1
            // 
            this.tb_dwcam1_to_upcam1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.tb_dwcam1_to_upcam1.Controls.Add(this.affineCail_Dw1ToUp1);
            this.tb_dwcam1_to_upcam1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_dwcam1_to_upcam1.Location = new System.Drawing.Point(214, 4);
            this.tb_dwcam1_to_upcam1.Name = "tb_dwcam1_to_upcam1";
            this.tb_dwcam1_to_upcam1.Size = new System.Drawing.Size(0, 15);
            this.tb_dwcam1_to_upcam1.TabIndex = 4;
            this.tb_dwcam1_to_upcam1.Text = "下相机1->上相机1";
            // 
            // affineCail_Dw1ToUp1
            // 
            this.affineCail_Dw1ToUp1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.affineCail_Dw1ToUp1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.affineCail_Dw1ToUp1.Location = new System.Drawing.Point(0, 0);
            this.affineCail_Dw1ToUp1.Margin = new System.Windows.Forms.Padding(4);
            this.affineCail_Dw1ToUp1.Name = "affineCail_Dw1ToUp1";
            this.affineCail_Dw1ToUp1.Size = new System.Drawing.Size(0, 15);
            this.affineCail_Dw1ToUp1.TabIndex = 0;
            // 
            // tb_dwcam2_to_upcam2
            // 
            this.tb_dwcam2_to_upcam2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.tb_dwcam2_to_upcam2.Controls.Add(this.affineCail_Dw2ToUp2);
            this.tb_dwcam2_to_upcam2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_dwcam2_to_upcam2.Location = new System.Drawing.Point(214, 4);
            this.tb_dwcam2_to_upcam2.Name = "tb_dwcam2_to_upcam2";
            this.tb_dwcam2_to_upcam2.Size = new System.Drawing.Size(0, 15);
            this.tb_dwcam2_to_upcam2.TabIndex = 5;
            this.tb_dwcam2_to_upcam2.Text = "下相机2->上相机2";
            // 
            // affineCail_Dw2ToUp2
            // 
            this.affineCail_Dw2ToUp2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.affineCail_Dw2ToUp2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.affineCail_Dw2ToUp2.Location = new System.Drawing.Point(0, 0);
            this.affineCail_Dw2ToUp2.Margin = new System.Windows.Forms.Padding(4);
            this.affineCail_Dw2ToUp2.Name = "affineCail_Dw2ToUp2";
            this.affineCail_Dw2ToUp2.Size = new System.Drawing.Size(0, 15);
            this.affineCail_Dw2ToUp2.TabIndex = 1;
            // 
            // Tb_ComputeCenter
            // 
            this.Tb_ComputeCenter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.Tb_ComputeCenter.Controls.Add(this.rotAndFly1);
            this.Tb_ComputeCenter.Controls.Add(this.button32);
            this.Tb_ComputeCenter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tb_ComputeCenter.Location = new System.Drawing.Point(214, 4);
            this.Tb_ComputeCenter.Name = "Tb_ComputeCenter";
            this.Tb_ComputeCenter.Padding = new System.Windows.Forms.Padding(3);
            this.Tb_ComputeCenter.Size = new System.Drawing.Size(0, 15);
            this.Tb_ComputeCenter.TabIndex = 1;
            this.Tb_ComputeCenter.Text = "旋转中心计算";
            // 
            // rotAndFly1
            // 
            this.rotAndFly1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.rotAndFly1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rotAndFly1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rotAndFly1.Location = new System.Drawing.Point(3, 3);
            this.rotAndFly1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rotAndFly1.Name = "rotAndFly1";
            this.rotAndFly1.Size = new System.Drawing.Size(0, 9);
            this.rotAndFly1.TabIndex = 2;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(869, 842);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(160, 66);
            this.button32.TabIndex = 1;
            this.button32.Text = "保存";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // tb_task_npoint
            // 
            this.tb_task_npoint.Controls.Add(this.taskNpoint1);
            this.tb_task_npoint.Location = new System.Drawing.Point(214, 4);
            this.tb_task_npoint.Name = "tb_task_npoint";
            this.tb_task_npoint.Size = new System.Drawing.Size(0, 15);
            this.tb_task_npoint.TabIndex = 6;
            this.tb_task_npoint.Text = "任务标定";
            this.tb_task_npoint.UseVisualStyleBackColor = true;
            // 
            // taskNpoint1
            // 
            this.taskNpoint1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(225)))), ((int)(((byte)(232)))));
            this.taskNpoint1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.taskNpoint1.Font = new System.Drawing.Font("宋体", 9F);
            this.taskNpoint1.Location = new System.Drawing.Point(0, 0);
            this.taskNpoint1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.taskNpoint1.Name = "taskNpoint1";
            this.taskNpoint1.Size = new System.Drawing.Size(0, 15);
            this.taskNpoint1.TabIndex = 0;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70.97701F));
            this.tableLayoutPanel5.Controls.Add(this.CogRecordDisplay_sys, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(1074, 618);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // CogRecordDisplay_sys
            // 
            this.CogRecordDisplay_sys.BackColor = System.Drawing.Color.Transparent;
            this.CogRecordDisplay_sys.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CogRecordDisplay_sys.Location = new System.Drawing.Point(3, 3);
            this.CogRecordDisplay_sys.Name = "CogRecordDisplay_sys";
            this.CogRecordDisplay_sys.Size = new System.Drawing.Size(1068, 612);
            this.CogRecordDisplay_sys.TabIndex = 0;
            // 
            // tmr_update
            // 
            this.tmr_update.Interval = 500;
            this.tmr_update.Tick += new System.EventHandler(this.tmr_update_Tick);
            // 
            // groupBox53
            // 
            this.groupBox53.Controls.Add(this.label47);
            this.groupBox53.Controls.Add(this.nud_UpWsChkQrCodeCnt);
            this.groupBox53.Controls.Add(this.rbtn_UpWsChkQrCodeOff);
            this.groupBox53.Controls.Add(this.rbtn_UpWsChkQrCodeOn);
            this.groupBox53.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox53.Location = new System.Drawing.Point(830, 43);
            this.groupBox53.Name = "groupBox53";
            this.groupBox53.Size = new System.Drawing.Size(152, 178);
            this.groupBox53.TabIndex = 148;
            this.groupBox53.TabStop = false;
            this.groupBox53.Text = "工站上料检二维码";
            // 
            // nud_UpWsChkQrCodeCnt
            // 
            this.nud_UpWsChkQrCodeCnt.BackColor = System.Drawing.SystemColors.Window;
            this.nud_UpWsChkQrCodeCnt.DecimalPlaces = 1;
            this.nud_UpWsChkQrCodeCnt.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_UpWsChkQrCodeCnt.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_UpWsChkQrCodeCnt.Location = new System.Drawing.Point(27, 122);
            this.nud_UpWsChkQrCodeCnt.Name = "nud_UpWsChkQrCodeCnt";
            this.nud_UpWsChkQrCodeCnt.Size = new System.Drawing.Size(82, 32);
            this.nud_UpWsChkQrCodeCnt.TabIndex = 131;
            this.nud_UpWsChkQrCodeCnt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_UpWsChkQrCodeCnt.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // rbtn_UpWsChkQrCodeOff
            // 
            this.rbtn_UpWsChkQrCodeOff.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_UpWsChkQrCodeOff.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_UpWsChkQrCodeOff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_UpWsChkQrCodeOff.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_UpWsChkQrCodeOff.ForeColor = System.Drawing.Color.Black;
            this.rbtn_UpWsChkQrCodeOff.Location = new System.Drawing.Point(27, 64);
            this.rbtn_UpWsChkQrCodeOff.Name = "rbtn_UpWsChkQrCodeOff";
            this.rbtn_UpWsChkQrCodeOff.Size = new System.Drawing.Size(71, 30);
            this.rbtn_UpWsChkQrCodeOff.TabIndex = 126;
            this.rbtn_UpWsChkQrCodeOff.Text = "关闭";
            this.rbtn_UpWsChkQrCodeOff.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_UpWsChkQrCodeOff.UseVisualStyleBackColor = true;
            // 
            // rbtn_UpWsChkQrCodeOn
            // 
            this.rbtn_UpWsChkQrCodeOn.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbtn_UpWsChkQrCodeOn.Checked = true;
            this.rbtn_UpWsChkQrCodeOn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.rbtn_UpWsChkQrCodeOn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbtn_UpWsChkQrCodeOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtn_UpWsChkQrCodeOn.ForeColor = System.Drawing.Color.Black;
            this.rbtn_UpWsChkQrCodeOn.Location = new System.Drawing.Point(27, 24);
            this.rbtn_UpWsChkQrCodeOn.Name = "rbtn_UpWsChkQrCodeOn";
            this.rbtn_UpWsChkQrCodeOn.Size = new System.Drawing.Size(71, 30);
            this.rbtn_UpWsChkQrCodeOn.TabIndex = 124;
            this.rbtn_UpWsChkQrCodeOn.TabStop = true;
            this.rbtn_UpWsChkQrCodeOn.Text = "开启";
            this.rbtn_UpWsChkQrCodeOn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbtn_UpWsChkQrCodeOn.UseVisualStyleBackColor = true;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(29, 105);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(63, 14);
            this.label47.TabIndex = 132;
            this.label47.Text = "弹窗频率";
            // 
            // FrSys
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1294, 788);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrSys";
            this.Text = "FrSys";
            this.Load += new System.EventHandler(this.FrSys_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ctb_sys.ResumeLayout(false);
            this.tp_card.ResumeLayout(false);
            this.tp_card.PerformLayout();
            this.tp_axis.ResumeLayout(false);
            this.tp_axis.PerformLayout();
            this.ctb_ax_sel.ResumeLayout(false);
            this.tp_gpio.ResumeLayout(false);
            this.tp_gpio.PerformLayout();
            this.ctb_io_type.ResumeLayout(false);
            this.tp_sysparm.ResumeLayout(false);
            this.ctb_SetParm.ResumeLayout(false);
            this.tp_setparm_1.ResumeLayout(false);
            this.groupBox44.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nud_TestTime)).EndInit();
            this.groupBox39.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nud_JigSendTime)).EndInit();
            this.groupBox38.ResumeLayout(false);
            this.groupBox45.ResumeLayout(false);
            this.groupBox43.ResumeLayout(false);
            this.groupBox42.ResumeLayout(false);
            this.groupBox41.ResumeLayout(false);
            this.groupBox40.ResumeLayout(false);
            this.groupBox34.ResumeLayout(false);
            this.groupBox34.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ngscale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ngcode)).EndInit();
            this.groupBox29.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.grb_safe.ResumeLayout(false);
            this.grb_safe.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_OpenDly)).EndInit();
            this.groupBoxbarcode.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SameRowNGTipCnt)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MovUpDly)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PlaceDly)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_vschk_rofs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_vschk_xyofs)).EndInit();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SameNGTipCnt)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_grrtudlcnt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_grrtestcnt)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_dwCam_xt4_ofs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_dwCam_xt3_ofs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_dwCam_xt2_ofs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_dwCam_xt1_ofs)).EndInit();
            this.grb_barcode.ResumeLayout(false);
            this.grb_runmode.ResumeLayout(false);
            this.grb_workmode.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_EquipmentMaintain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FixtrueMaintain)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GTMOfs)).EndInit();
            this.tp_setparm_2.ResumeLayout(false);
            this.groupBox48.ResumeLayout(false);
            this.groupBox48.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Areaofset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DownArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_UpArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_RightArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_LeftArea)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Areaofset2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DownArea2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_UpArea2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_RightArea2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_LeftArea2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox47.ResumeLayout(false);
            this.groupBox46.ResumeLayout(false);
            this.groupBox37.ResumeLayout(false);
            this.groupBox36.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nud_okRate)).EndInit();
            this.groupBox35.ResumeLayout(false);
            this.groupBox33.ResumeLayout(false);
            this.groupBox32.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_jig_exposure2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_jig_contrast2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_jig_brightness2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_jig_exposure1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_jig_contrast1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_jig_brightness1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ws_exposure2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tray_exposure2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ws_contrast2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ws_brightness2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tray_contrast2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tray_brightness2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ws_exposure1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tray_exposure1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ws_contrast1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ws_brightness1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tray_contrast1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tray_brightness1)).EndInit();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_cleaninterval)).EndInit();
            this.groupBox27.ResumeLayout(false);
            this.groupBox26.ResumeLayout(false);
            this.groupBox24.ResumeLayout(false);
            this.groupBox23.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox21.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_offset_degree)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox52.ResumeLayout(false);
            this.groupBox52.PerformLayout();
            this.groupBox49.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.groupBox50.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.groupBox51.ResumeLayout(false);
            this.tp_calc.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.ctb_cali.ResumeLayout(false);
            this.tb_upcam1_npoint.ResumeLayout(false);
            this.tb_dwcam1_to_upcam1.ResumeLayout(false);
            this.tb_dwcam2_to_upcam2.ResumeLayout(false);
            this.Tb_ComputeCenter.ResumeLayout(false);
            this.tb_task_npoint.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.groupBox53.ResumeLayout(false);
            this.groupBox53.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_UpWsChkQrCodeCnt)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TabPage tp_gpio;
        private System.Windows.Forms.TabPage tp_axis;
        private System.Windows.Forms.TabPage tp_sysparm;
        public CTabControl ctb_sys;
        private System.Windows.Forms.Timer tmr_update;
        private System.Windows.Forms.TabPage tp_calc;
        private System.Windows.Forms.Button btn_load_axis_cfg;
        private System.Windows.Forms.Button btn_save_axis_cfg;
        private MotionCtrl.AxisConfig axisConfig;
        private MotionCtrl.AxisTable axisTable;
        private System.Windows.Forms.Label label_ax_table;
        private System.Windows.Forms.Label label10;
        private CTabControl ctb_ax_sel;
        private System.Windows.Forms.TabPage ctp_ax_all;
        private System.Windows.Forms.TabPage ctp_ax_udl1;
        private System.Windows.Forms.TabPage ctp_ax_udl2;
        private System.Windows.Forms.TabPage ctp_ax_box_left;
        private System.Windows.Forms.TabPage ctp_ax_box_right;
        private System.Windows.Forms.TabPage ctp_ax_ws;
        private System.Windows.Forms.TabPage ctp_ax_otp;
        private System.Windows.Forms.TabPage tp_card;
        private MotionCtrl.CardTable CardTable;
        private MotionCtrl.CylinderTable cylinderTable;
        private MotionCtrl.IOTable ioTable;
        private System.Windows.Forms.Label lb_card_update_ms;
        private System.Windows.Forms.Label lb_ax_update_ms;
        private System.Windows.Forms.Label lb_io_update_ms;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Button btn_update_card;
        private CTabControl ctb_io_type;
        private System.Windows.Forms.TabPage tp_out;
        private System.Windows.Forms.TabPage tp_in;
        private System.Windows.Forms.TabPage tp_cy;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        public CTabControl ctb_cali;
        private System.Windows.Forms.TabPage tb_upcam1_npoint;
        private System.Windows.Forms.TabPage tb_dwcam1_to_upcam1;
        private System.Windows.Forms.TabPage tb_dwcam2_to_upcam2;
        private System.Windows.Forms.TabPage Tb_ComputeCenter;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        public CogDisplayer CogRecordDisplay_sys;
        private System.Windows.Forms.TabPage ctp_ax_lc;
        private System.Windows.Forms.TabPage tb_task_npoint;
        private System.Windows.Forms.GroupBox grb_barcode;
        private System.Windows.Forms.GroupBox grb_workmode;
        private System.Windows.Forms.RadioButton rbtn_md2;
        private System.Windows.Forms.RadioButton rbtn_twomd;
        private System.Windows.Forms.RadioButton rbtn_md1;
        private System.Windows.Forms.RadioButton rbtn_dwcode;
        private System.Windows.Forms.RadioButton rbtn_upcode;
        private System.Windows.Forms.Button btn_ptset_save;
        private System.Windows.Forms.GroupBox grb_runmode;
        private System.Windows.Forms.RadioButton rbtn_run_updw;
        private System.Windows.Forms.RadioButton rbtn_run_empty;
        private System.Windows.Forms.RadioButton rbtn_run_normal;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbtn_CloseVsTray;
        private System.Windows.Forms.RadioButton rbtn_OpenVsTray;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox chk_grr;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nud_grrtudlcnt;
        private System.Windows.Forms.NumericUpDown nud_grrtestcnt;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.NumericUpDown nud_vschk_rofs;
        private System.Windows.Forms.NumericUpDown nud_vschk_xyofs;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox Chk_OpenVs;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown nud_MovUpDly;
        private System.Windows.Forms.NumericUpDown nud_PlaceDly;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox Chk_ModPasteUp;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.NumericUpDown nud_dwCam_xt1_ofs;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nud_dwCam_xt4_ofs;
        private System.Windows.Forms.NumericUpDown nud_dwCam_xt3_ofs;
        private System.Windows.Forms.NumericUpDown nud_dwCam_xt2_ofs;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RadioButton rbtn_CloseWsVsAddCheck;
        private System.Windows.Forms.RadioButton rbtn_OpenWsVsAddCheck;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.NumericUpDown nud_GTMOfs;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox chk_GTMCheck;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.NumericUpDown nud_EquipmentMaintain;
        private System.Windows.Forms.NumericUpDown nud_FixtrueMaintain;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.RadioButton rbtn_CloseWsPickAgain;
        private System.Windows.Forms.RadioButton rbtn_OpenWsPickAgain;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.RadioButton rbtn_lbdis;
        private System.Windows.Forms.RadioButton rbtn_lben;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.NumericUpDown nud_offset_degree;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RadioButton rbtn_close_degree;
        private System.Windows.Forms.RadioButton rbtn_open_degree;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.NumericUpDown nud_SameNGTipCnt;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.CheckBox chk_SameNGTip;
        private CTabControl ctb_SetParm;
        private System.Windows.Forms.TabPage tp_setparm_1;
        private System.Windows.Forms.TabPage tp_setparm_2;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.NumericUpDown nud_SameRowNGTipCnt;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox chk_SameRowNGTip;
        private System.Windows.Forms.Button btn_saveparm2;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.RadioButton rbtn_single;
        private System.Windows.Forms.RadioButton rbtn_double;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.RadioButton rbtn_big;
        private System.Windows.Forms.RadioButton rbtn_small;
        private System.Windows.Forms.RadioButton rbtn_Lag;
        private System.Windows.Forms.RadioButton rbtn_Sml;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.RadioButton rbtn_traybardis;
        private System.Windows.Forms.RadioButton rbtn_traybaren;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.RadioButton rbtn_halldis;
        private System.Windows.Forms.RadioButton rbtn_hallen;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.RadioButton rbtn_xt1firstdis;
        private System.Windows.Forms.RadioButton rbtn_xt1firsten;
        public Compment.AffineCail affineCail_Dw1ToUp1;
        public Compment.AffineCail affineCail_Dw2ToUp2;
        public Compment.RotAndFly rotAndFly1;
        public Compment.NpointCail npointCail1;
        public Compment.TaskNpoint taskNpoint1;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.RadioButton rbtn_RY1dis;
        private System.Windows.Forms.RadioButton rbtn_RY1en;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.RadioButton rbtn_backerrcontinuedis;
        private System.Windows.Forms.RadioButton rbtn_backerrcontinueen;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.RadioButton rbtn_nonparalleldis;
        private System.Windows.Forms.RadioButton rbtn_nonparallelen;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.RadioButton rbtn_cleandis;
        private System.Windows.Forms.RadioButton rbtn_cleanen;
        private System.Windows.Forms.NumericUpDown nud_cleaninterval;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.NumericUpDown nud_tray_brightness1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RadioButton rbtn_camcfgsetdis;
        private System.Windows.Forms.RadioButton rbtn_camcfgseten;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown nud_ws_contrast1;
        private System.Windows.Forms.NumericUpDown nud_ws_brightness1;
        private System.Windows.Forms.NumericUpDown nud_tray_contrast1;
        private System.Windows.Forms.NumericUpDown nud_ws_exposure1;
        private System.Windows.Forms.NumericUpDown nud_tray_exposure1;
        private System.Windows.Forms.NumericUpDown nud_ws_exposure2;
        private System.Windows.Forms.NumericUpDown nud_tray_exposure2;
        private System.Windows.Forms.NumericUpDown nud_ws_contrast2;
        private System.Windows.Forms.NumericUpDown nud_ws_brightness2;
        private System.Windows.Forms.NumericUpDown nud_tray_contrast2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.NumericUpDown nud_tray_brightness2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.RadioButton rbtn_OkCheckDis;
        private System.Windows.Forms.RadioButton rbtn_OkCheckEn;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.CheckBox chk_UpLoadData;
        private System.Windows.Forms.CheckBox chk_UpdateSoft;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox chk_dwcam2;
        private System.Windows.Forms.CheckBox chk_upcam2;
        private System.Windows.Forms.CheckBox chk_dwcam1;
        private System.Windows.Forms.CheckBox chk_upcam1;
        private System.Windows.Forms.GroupBox grb_safe;
        private System.Windows.Forms.CheckBox chk_rightlightbox;
        private System.Windows.Forms.CheckBox chk_tray;
        private System.Windows.Forms.CheckBox chk_leftlightbox;
        private System.Windows.Forms.CheckBox chk_updown;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.NumericUpDown nud_OpenDly;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RadioButton rbtn_next_turnon;
        private System.Windows.Forms.RadioButton rbtn_pre_turnon;
        private System.Windows.Forms.GroupBox groupBoxbarcode;
        private System.Windows.Forms.RadioButton rbtn_CloseBarCamBack;
        private System.Windows.Forms.RadioButton rbtn_OpenBarCamBack;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.RadioButton rbtn_CycleDis;
        private System.Windows.Forms.RadioButton rbtn_CycleEn;
        private System.Windows.Forms.GroupBox groupBox32;
        private System.Windows.Forms.RadioButton rbtn_cooldis;
        private System.Windows.Forms.RadioButton rbtn_coolen;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.RadioButton rbtn_delaytestdis;
        private System.Windows.Forms.RadioButton rbtn_delaytesten;
        private System.Windows.Forms.GroupBox groupBox34;
        private System.Windows.Forms.NumericUpDown nud_ngscale;
        private System.Windows.Forms.NumericUpDown nud_ngcode;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.RadioButton rbtn_ngcontroldis;
        private System.Windows.Forms.RadioButton rbtn_ngcontrolen;
        private System.Windows.Forms.GroupBox groupBox35;
        private System.Windows.Forms.RadioButton rbtn_ContinuousAlarmDis;
        private System.Windows.Forms.RadioButton rbtn_ContinuousAlarmEn;
        private System.Windows.Forms.GroupBox groupBox36;
        private System.Windows.Forms.NumericUpDown nud_okRate;
        private System.Windows.Forms.RadioButton rbtn_NgWarningDis;
        private System.Windows.Forms.RadioButton rbtn_NgWarningEn;
        private System.Windows.Forms.GroupBox groupBox37;
        private System.Windows.Forms.RadioButton rbtn_MesRemote;
        private System.Windows.Forms.RadioButton rbtn_MesLocal;
        private System.Windows.Forms.GroupBox groupBox38;
        private System.Windows.Forms.RadioButton btnStopJigSan;
        private System.Windows.Forms.RadioButton btnStartJigSan1;
        private System.Windows.Forms.GroupBox groupBox39;
        private System.Windows.Forms.NumericUpDown nud_JigSendTime;
        private System.Windows.Forms.GroupBox groupBox43;
        private System.Windows.Forms.RadioButton btnStartJigSan4;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.GroupBox groupBox42;
        private System.Windows.Forms.RadioButton btnStartJigSan3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.GroupBox groupBox41;
        private System.Windows.Forms.RadioButton btnStartJigSan2;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.GroupBox groupBox40;
        private System.Windows.Forms.GroupBox groupBox45;
        private System.Windows.Forms.RadioButton rabt_jigscan_ON;
        private System.Windows.Forms.RadioButton rabt_jigscan_OFF;
        private System.Windows.Forms.GroupBox groupBox44;
        private System.Windows.Forms.NumericUpDown nud_TestTime;
        private System.Windows.Forms.NumericUpDown nud_jig_exposure2;
        private System.Windows.Forms.NumericUpDown nud_jig_contrast2;
        private System.Windows.Forms.NumericUpDown nud_jig_brightness2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.NumericUpDown nud_jig_exposure1;
        private System.Windows.Forms.NumericUpDown nud_jig_contrast1;
        private System.Windows.Forms.NumericUpDown nud_jig_brightness1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox46;
        private System.Windows.Forms.RadioButton rbtn_AddCapQrcodeDis;
        private System.Windows.Forms.RadioButton rbtn_AddCapQrcodeEn;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rad_light_xsj;
        private System.Windows.Forms.RadioButton rad_G4C;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton rbtn_Y1dis;
        private System.Windows.Forms.RadioButton rbtn_Y1en;
        private System.Windows.Forms.GroupBox groupBox47;
        private System.Windows.Forms.RadioButton rbtn_safeoff;
        private System.Windows.Forms.RadioButton rbtn_safeon;
        private System.Windows.Forms.RadioButton rbtn_NoCap;
        private System.Windows.Forms.GroupBox groupBox48;
        private System.Windows.Forms.CheckBox cb_ConnectorCheck;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.NumericUpDown nud_Areaofset;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.NumericUpDown nud_DownArea;
        private System.Windows.Forms.NumericUpDown nud_UpArea;
        private System.Windows.Forms.NumericUpDown nud_RightArea;
        private System.Windows.Forms.NumericUpDown nud_LeftArea;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.NumericUpDown nud_Areaofset2;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.NumericUpDown nud_DownArea2;
        private System.Windows.Forms.NumericUpDown nud_UpArea2;
        private System.Windows.Forms.NumericUpDown nud_RightArea2;
        private System.Windows.Forms.NumericUpDown nud_LeftArea2;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox49;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox50;
        private System.Windows.Forms.RadioButton rbtUpDn1OneXtOff;
        private System.Windows.Forms.RadioButton rbtUpDn1OneXtOn;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox51;
        private System.Windows.Forms.RadioButton rbtUpDn2OneXtOff;
        private System.Windows.Forms.RadioButton rbtUpDn2OneXtOn;
        private System.Windows.Forms.GroupBox groupBox52;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox tb_eqp_pos;
        private System.Windows.Forms.TextBox tb_eqp_sn;
        private System.Windows.Forms.GroupBox groupBox53;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.NumericUpDown nud_UpWsChkQrCodeCnt;
        private System.Windows.Forms.RadioButton rbtn_UpWsChkQrCodeOff;
        private System.Windows.Forms.RadioButton rbtn_UpWsChkQrCodeOn;
    }
}